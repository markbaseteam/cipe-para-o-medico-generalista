---
layout: page
title: Home
id: home
permalink: /
---

## Bem-vindos! 🌱

Olá o objetivo desta página é se tornar um [jardim digital](https://medium.com/contraforma/o-que-e-jardim-digital-7029673da847) e não um [blog](https://rockcontent.com/br/blog/o-que-e-blog/) sobre temas de cirurgia pediátrica para o médico generalista.

Iniciado a partir de um minicurso ofertado aos alunos do internato do curso de medicina da [Universidade Federal da Paraíba](https://www.ufpb.br/).

Os temas se baseiam em problemas que envolvem cirurgia pediátrica e que podem ser encontrados pelo médico generalista e recém-formado nas unidades básicas de saúde.

Os seguintes temas são abordados no curso e abrangem uma variedade de patologias que podem provocar o problema em questão:

- [[Abaulamentos inguinais e escrotais]]
- [[Infecção urinária na infância]]
- [[A criança ictérica]]
- [[Meu bebê precisa de cirurgia|Meu bebê precisa de cirurgia?]]
- [[dor abdominal|Dor abdominal no PS. E agora?]]
- [[Meu filho está tossindo]]
