---
title: "Vômitos"
---

Os [[vômitos]] ocorrem devido a contração do estômago o que leva aos relatos da mãe de que os mesmos _são em jato_ ou se projetam com certa velocidade através da boca da criança o que pode ser usado para diferenciá-los das regurgitações ([golfos](https://michaelis.uol.com.br/moderno-portugues/busca/portugues-brasileiro/golfar/)) que também acontecem neste período devido a imaturidade nos mecanismos que aumentam a pressão na transição esôfago gástrica e impedem o [[rge|refluxo gastro-esofágico]].

_Regurgitação_ -- é possível imaginar como exemplo uma garrafa plástica cheia de água sem tampa. Se virarmos a mesma na horizontal o conteúdo irá escorrer pelo gargalo. 

_Vômito_ -- no entanto, se mantivermos a posição vertical e comprimirmos a meia altura entre o gargalo e o fundo é provável que o líquido seja ejetado com alguma velocidade para fora da mesma.
