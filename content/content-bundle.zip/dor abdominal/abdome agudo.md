---
title: "Abdome agudo"
---

### Importância

Diagnosticar alguém com _abdome agudo_ pode parecer supérfluo. Os diagnósticos específicos são mais precisos em estabelecer  prognósticos e tratamentos. Mas se pensarmos o diagnóstico no pronto-socorro como um **processo**, centralizar nossos esforços em encontrar uma causa para o _abdome agudo_ do paciente é mais eficiente que tentarmos encaixar o quadro clínico em um espectro de possibilidades maior. Por exemplo a febre interpretada no contexto de um abdome agudo terá um significado diferente de quando vista sob o espectro de uma tosse produtiva. 

### Classificação

Após a definição de que a causa dos sintomas do paciente é um __abdome agudo__. Podemos ser mais específicos e sub-classificar este diagnóstico em quatro grandes grupos que podem se sobrepor.

- inflamatório
- obstrutivo
	- alto
	- baixo
- perfurativo
- vascular

Na criança esta classificação guarda o mesmo significado que no adulto no entanto representam doenças diferentes. Especialmente quando observamos as causas de abdome agudo obstrutivo.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696147/garden/notas-cipe/abdome_agudo.jpg %}


Essas subdivisões não contém quadros clínicos estáticos. Ou seja, um processo obstrutivo pode levar a perfuração e inflamação; podendo ainda coexistirem. Nas crianças os tipos perfurativo e vascular ocorrem mais raramente e em situações específicas associadas geralmente a mal formações cardíacas, do trato gastrintestinal ou com a prematuridade e baixo peso.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696150/garden/notas-cipe/abdome_agudo_fluxo.jpg %}


### Quadro clínico

A dor é o principal discriminante dos subtipos de abdome agudo. Clinicamente podemos caracteriza-la em 2 tipos: dor somática e visceral ou em cólica.
A dor visceral ocorre quando temos distensão, torção ou estiramento das fibras musculares lisas. Como exemplo temos a cólica, biliar, nefrética, uterina, intestinal. Esses estímulos são transmitidos através do sistema nervoso autônomo que por sua vez é adaptado a percepção e controle de estímulos sensoriais responsáveis pela manutenção das nossas funções automáticas.
