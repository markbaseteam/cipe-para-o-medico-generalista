---
title: "Divertículo de Meckel"
---

### Conceito 

O divertículo de Meckel é um tipo de persistência do [[conduto onfalomesentérico]] onde persiste como um remanescente no íleo terminal a cerca de 90cm da válvula íleo-cecal.

### Epidemiologia

É a malformação congênita mais comum do trato gastrointestinal com uma prevalência de cerca de 2% da população. No entanto é muito pouco diagnosticado uma vez que isso só ocorre quando o mesmo apresenta sintomas e isso acontece somente em 4% a 6% dos pacientes ao longo da vida.

### Patogenia

O divertículo é revestido internamente por mucosa ileal. Apesar disso até 40% dos pacientes apresentam mucosa heterotópica no divertículo, gástrica e pancreática. Quando isto ocorre pode haver inflamação (tecido pancreático) ou formação de úlceras pépticas (mucosa gástrica). Levando as complicações.

### Diagnóstico

O divertículo de Meckel pode complicar de 4 formas.
- sangramento
- intussuscepção/obstrução
- diverticulite
- estenose

O sangramento é a forma mais frequente de complicação na criança 45% a 50% dos casos seguida da obstrução e diverticulite.

A diverticulite ocorre com mais frequência em escolares e adolescentes e deve ser suspeitado sempre nos casos de abdome agudo inflamatório com apêndice cecal normal.

Nos adultos é comum as torções do divertículo e o volvo que podem estar relacionados a outros tipos de [[conduto onfalomesentérico|persistência do conduto onfalomesentérico]].

A cintilografia com tecnécio 99 (T<sup>99</sup>) é o exame padrão ouro para a pesquisa do divertículo de Meckel. Possui uma acurácia de até 90% em crianças. Em adultos essa sensibilidade diminui devido ao menor número de pacientes com mucosa gástrica heterotópica.

A ultrassonografia é útil nos casos que apresentam complicações como diverticulite e intussuscepção.


### Tratamento 

O tratamento é cirúrgico e pode ser por laparotomia ou laparoscopia nos casos de complicações deve ser realizada a enterectomia com enteroanastomose termino terminal. 

Alguns cirurgiões realizam a diverticulectomia em casos de achado incidental no intraoperatório.

O tratamento do divertículo achado de forma incidental durante um procedimento cirúrgico é discutível. Existe evidência de que o risco de complicações é baixo ao longo dos anos. 
