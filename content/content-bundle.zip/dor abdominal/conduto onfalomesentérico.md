---
title: "Embriologia do conduto onfalomesentérico"
author: "Daniel Rangel"
created_at: 2022-05-22
---

### Embriologia

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653255045/garden/notas-cipe/conduto_onfalomesenterico_A_gnklra.png %}

A -- Um embrião de 1,7mm 3<sup>a</sup> semanas de idade gestacional o intestino primitivo ainda se encontra em continuidade com o grande saco vitelínico na porção ventral do embrião. A cavidade amniótica se forma na parte dorsal e os vasos umbilicais começam a se formar no mesoderma extra-embrionário que dará origem a placenta.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653255036/garden/notas-cipe/conduto_onfalomesenterico_B_nqitds.png %}

B -- Na quarta semana de gestação o embrião se curva ventralmente fazendo com que a cavidade amniótica envolva a porção cranial e caudal do mesmo. O saco vitelínico se comunica com o intestino primitivo e começa a fazer parte do cordão umbilical em formação. 

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653255038/garden/notas-cipe/conduto_onfalomesenterico_C_nb0don.png %}

C -- Quinta semana de idade gestacional, embrião de 5mm. Neste período o saco vitelínico perde a comunicação com o intestino primitivo, permanecendo um conduto obliterado que segue pelo cordão umbilical já completamente formado.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653255041/garden/notas-cipe/conduto_onfalomesenterico_D_bi0xh8.png %}

D -- Um embrião de 45mm na décima semana gestacional. Mostrando uma visão do umbigo por dentro da cavidade abdominal. É possível ver o conduto onfalomesentérico partindo em direção ao íleo. A veia e artérias umbilicais. E a bexiga com o úraco(resquício embriológico da comunicação com o [[alantoide]]) saindo do seu ápice.


### Persistência do conduto onfalomesentérico

A persistência do conduto onfalomesentérico após o nascimento podem se apresentar clinicamente de diversas formas de acordo com a anatomia da persistência. O mais comum é a formação de cistos, fístulas, seios, bandas fibróticas e o [[divertículo de Meckel]].


{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653267940/garden/notas-cipe/conduto_onfalo_mesenterico_-_Frame_1_wzze6w.jpg %}