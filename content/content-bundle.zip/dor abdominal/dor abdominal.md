---
layout: page
title: "Dor abdominal no pronto-socorro e agora?"
permalink: /dor-abdominal
---

## Dor abdominal no pronto-socorro e agora?

- [[apendicite aguda]]
- [[estenose hipertrófica de piloro]]
- [[invaginação intestinal]]
- [[colelitíase]]
- [[nefrolitíase]]
- [[volvo de intestino médio]]
- [[divertículo de Meckel]]

### Objetivos

#### Saber

- identificar o [[abdome agudo]] no pronto-socorro e qual a importância de fazê-lo. 
- quais as causas de abdome agudo na criança.
- diferenciar abdome agudo inflamatório e obstrutivo na criança.
- quando e com qual propósito se deve solicitar exames complementares no pronto-socorro.
- tomar as condutas iniciais no tratamento dos pacientes com abdome agudo e quando encaminhar para o especialista. 