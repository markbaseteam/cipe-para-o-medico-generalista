---
titlw: "Intussuscepção intestinal"
---

### Conceito

A intussuscepção intestinal é a invaginação (telescopagem) do intestino sobre ele próprio. É uma causa importante de [[abdome agudo]] obstrutivo baixo em crianças. Mais especificamente abaixo dos 2 anos de idade.

### Epidemiologia

Possui um pico de incidência dos 5 aos 9 meses de idade. Após os 2 anos é importante procurar outras causas para a intussuscepção ([[divertículo de Meckel]], pólipos, cistos enterógenos, linfomas).

### Clínica

A forma mais comum é a invaginação do íleo terminal no ceco. O peristaltismo pode levar o ponto inicial da intussuscepção por todo o intestino grosso.

O paciente apresenta vômitos, distensão abdominal, parada de eliminação de flatos e fezes. Choro episódico, irritabilidade e recusa alimentar podem ser interprestados como dor abdominal em cólica. O quadro evolui rapidamente com queda do estado geral, apatia e sinais de má perfusão. É comum observar gemência e os pais podem relatar evacuações sanguinolentas.

Os pacientes podem chegar ao pronto-socorro com quadros graves de choque. Esses quadros podem significar necrose da alça invaginada e os pacientes devem ser avaliados inicialmente utilizando o [[triangulo de avaliação pediátrica]]. 

Os achados do exame físico são de abdome agudo obstrutivo. Pode ser palpada uma massa móvel e lobulada mais comumente em epigástrio mas podendo ocupar os quadrantes superiores e flancos do abdome. A dor e distensão com timpanismo a percussão também são achados comuns. Pacientes em mal estado geral com tempo prolongado de história e sinais de peritonite são candidatos a laparotomia pela alta probabilidade de necrose da alça invaginada. 

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653255035/garden/notas-cipe/geleia_morango_jo8ujs.jpg alt="toque retal com muco e sangue" %}

O toque retal deve ser realizado sempre que houver a suspeita de intussuscepção sem o relato dos pais sobre evacuações com sangue. Deve-se avaliar a temperatura, a presença de massas a textura da mucosa e após o exame se houve sangue, muco ou pus na luva ou em eventual evacuação.

### Exames complementares 

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652627083/garden/notas-cipe/sinal_alvo_qfqndk.png alt="ultrassonografia mostrando imagem em alvo" %}

A ultrassonografia irá mostrar duas imagens ecogênicas circunscritas. Representam o corte transversal de uma alça no interior da outra e é chamado de _imagem em alvo_.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652627010/garden/notas-cipe/rx_invaginacao_njoqsn.png %}

No raio x de abdome o mais comum é observar sinais de obstrução intestinal baixa como sinal do _empilhamento de moedas_, níveis hidro aéreos e distribuição irregular dos gases nos quadrantes abdominais. Eventualmente pode se observar uma imagem em _lua crescente_ representando a alça invaginada penetrando no interior de um bolsão de ar acumulado no cólon. 

