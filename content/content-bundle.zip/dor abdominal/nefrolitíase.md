---
title: Nefrolitíase
author: Daniel Rangel
created: 2022-06-02
---

### Introdução

Cálculos renais são raros em crianças. Contribuem com 2%-3% de todos os casos de litíase. Os cálculos secundários a infecções são os mais comuns e os meninos mais acometidos. A recorrência de nefrolitíase é menor em crianças que em adultos e atualmente são tratados da mesma forma com litotripsia e cirurgia urológica endoscópica.

### Fisiopatogenia

Os cálculos podem ser classificados em cálculos infecciosos e metabólicos.

__Cálculos infecciosos__ se originam da combinação de magnésio, fosfato de amônia e matriz glicoproteica. A partir dai o fosfato de cálcio se incorpora a massa calculosa em expansão aumentando sua densidade e radiopacidade.

__Cálculos metabólicos__ 


### Quadro clínico


