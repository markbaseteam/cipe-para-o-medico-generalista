---
title: "Colelitíase"
author: Daniel Rangel
tags: ictericia
---

### Conceito

A colelitíase é a doença mais comum que acomete as vias biliares.

### Epidemiologia

A colelitíase afeta 15% a 20% dos pacientes adultos em países ocidentais. Os cálculos se formam entre os 20 e 40 anos de vida e apresentam sintomas muito tempo após. Abaixo dos 19 anos a incidência é de 1% a 2%. Mas tem aumentado muito nas últimas décadas. Acredita-se que pela maior incidência de obesidade infantil e pelo uso de anticoncepcionais. Fatores conhecidamente predisponentes para a formação dos cálculos.

### Fisiopatogenia

A bile é formada por colesterol, sais biliares, lecitina e água. Os cálculos se formam pela precipitação do colesterol ou dos sais biliares formando cristais.[^1] Em crianças os cálculos escuros de sais biliares ocorrem pela metabolização da bilirrubina formada a partir da hemólise nas anemias hemolíticas.

O esvaziamento da vesícula biliar é um fator importante uma vez que em situações (nutrição parenteral, jejum prolongado, uso de somatostatina) onde sua motilidade está diminuída contribuem para o aparecimento de cálculos e _lama biliar_.

### Diagnóstico 

A maioria dos pacientes são assintomáticos. O risco de se ter complicações relacionadas



[^1]: Admirand WH, Small DM. _The physicochemical basis of cholesterol gallstone formation in man._ J Clin Invest. maio de 1968;47(5):1043–52.