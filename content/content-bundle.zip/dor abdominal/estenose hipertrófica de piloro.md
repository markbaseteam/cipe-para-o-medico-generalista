---
title: "Estenose hipertrófica de piloro"
---

### Definição

A estenose hipertrófica do piloro (**EHP**) o espessamento da camada muscular do piloro levando a sua obstrução e acarretando [[abdome agudo|abdome agudo obstrutivo alto]].

### Epidemiologia

A EHP é a causa mais comum de obstrução da via de saída do estômago na infância. 
- incidência de 1,5 a 4,0 por 1000 nascidos vivos em caucasianos
- menos frequente em asiáticos e descendentes africanos.
- mais comum em meninos numa proporção de 4:1. 
- relatos sugerem ser mais comum em primogênitos

### Etiologia

A etiologia da estenose hipertrófica de piloro na infância ainda é desconhecida. Vários estudos mostram múltiplas hipóteses que levam a alterações estruturais nas células da musculatura pilórica. Essas alterações ocorrem em fatores de crescimento, peptídeos gastrointestinais (gastrina, substância _P_, TGF-α, fator de crescimento epidérmico, somatostatina, secretina, enteroglucagon, etc.), neurotrofinas e na óxido nítrico sintetase. Essas substâncias levam por diferentes caminhos ao 

- não relaxamento das fibras musculares pilóricas,
- a alterações na transmissão nervosa e desenvolvimento de neurônios que se comunicam com as células musculares lisas, e  
- na hipertrofia das fibras musculares pilóricas.

### Quadro clínico

A história é de [[vômitos]] precoces após as mamadas que se iniciam de 2 a 8 semanas após o nascimento com pico entre a terceira e quinta semana. 
 
O [[vômitos|vômito]], irritabilidade, recusa alimentar e febre são sintomas muito comuns no período neonatal e estão presentes numa grande quantidade de doenças. É importante lembrar que o paciente com EHP não está infectado e salvo outras doenças concomitantes o achado de __febre é incomum__. Quadros infecciosos que cursam com vômitos como a [[infecção do trato urinário]] levam também a recusa alimentar do paciente o que não ocorre com a EHP onde o __bebê se encontra faminto__ mesmo após vomitar.

No exame físico do paciente que se encontra vomitando por um tempo prolongado devido a dificuldade em diferenciar o quadro do [[rge|refluxo gastro-esofágico]] podemos encontrar sinais de [[desidratação]] e [[distúrbios ácido-básicos]]. No exame específico para a EHP deve-se palpar o abdome no hipocôndrio direito a procura de uma oliva pilórica

### Tratamento

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652830279/garden/notas-cipe/piloro_wnhfkq.png %}

O estômago do paciente precisa ser descomprimido com sonda nasogástrica para prevenir aspiração de conteúdo gástrico para o pulmão e para quantificar e repor as perdas. Hemograma, elétrolitos e gasometria também podem ser solicitadas com intuito de estabilizar o paciente antes do tratamento cirúrgico.

O tratamento círúrgico é a piloromiotomia (cirurgia de Ramstedt-Fredet). É realizada uma incisão na musculatura do piloro com cuidado de não aprofundá-la até a mucosa mantendo-a integra.





