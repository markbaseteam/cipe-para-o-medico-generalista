---
title: "Apendicite Aguda"
author: "Daniel Rangel <daniel@rangel.in>"
created: 2021-03-20
alias: "acute appendicitis"
---

## Apendicite Aguda

### Anatomia

O apendice cecal é um orgão que se localiza na cavidade abdominal mais especificamente na fossa iliaca direita, se encontra conectado ao ceco na confluência das tênias musculares do intestino grosso. Pode em alguns casos estar em posição retrocecal ou pelvica influenciando o quadro clínico e o tratamento cirúrgico.


### Fisiopatogenia

A inflamação do apêndice ocorre após obstrução de sua luz em decorrência da hipertrofia do tecido linfóidide associado a mucosa (*MALT*). Esta obstrução ainda pode acontecer secundariamente a corpos estranhos como sementes vegetais, vermes, helmíntos e partículas de fezes ressecadas (*apendicolitos, fecalitos*).

A obstrução da luz apendicular acarreta o acúmulo de conteúdo fecal do cólon e proliferação bacteriana o que culmina com o aumento da pressão no interior do apêndice e redução na irrigacão da porção mais distal do apêndice que termina por isquemiar, necrosar e perfurar levando por vezes o paciente a quadros de peritonite localizada ou generalizada a depender da capacidade deste em conter o processo infeccioso localmente ou não.

### Quadro clínico

Alguns pacientes se queixam inicialmente de um desconforto abdominal que em horas ou minutos são identificados como dor epigástrica ou mesogástrica esta por sua vez migra para a fossa ilíaca direita a medida que o processo infeccioso e inflamatório apendicular atinge o peritônio inervado pelo [[sistema nervoso visceral aferente]]
