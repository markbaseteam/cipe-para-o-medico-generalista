---
title: "Anomalias Congênitas"
permalink: /congenitas
---

### Conceito

As anomalias congênitas (AC) é um termo bastante amplo que inclui doenças de vários órgãos espalhados por diversos sistemas. 
- As AC são alterações do desenvolvimento embrionário/fetal que afetam estrutura ou função do corpo. 

As anomalias congênitas podem ser classificadas em maiores e menores de acordo com a morbidade apresentada pelas mesmas. As _menores_ não levam a incapacidades ou problemas significativos para a qualidade de vida do paciente. As _maiores_ possuem origem no desenvolvimento embrionário o que leva a malformações complexas e incapacitantes do médico e social, no entanto, são menos frequentes na população.

O ministério da saúde lançou em 2021 [[anomalias congênitas prioritárias para a vigilância ao nascimento]]. Com objetivo de apresentar uma introdução às anomalias congênitas abordando conceitos, epidemiologia, fatores de risco assim como os aspectos relacionados com a notificação desses agravos.

### Patogenia

- Malformação -- resultado de problemas durante a formação do órgão ou estrutura. Ex.: Sindactilia
- Disrupção -- são alterações que ocorrem mais precocemente durante o desenvolvimento embrionário e consequentemente causam anormalidades estruturais graves. Ex.: Focomelia
- Displasia -- resulta da anormalidade na histogênese de um ou mais tecidos. Ex.: Osteogênese imperfeita
- Deformidade -- desenvolvimento inicial ocorre de maneira normal, contudo, dada a ação de forças mecânicas a estrutura se deforma. Ex.: pé torto congênito.


### Clínica

- Isolada -- apresenta somente uma anomalia.
- Sequência -- uma sucessão de alterações ou erros que são desencadeados por uma mesma malformação, disrupção ou deformidade.
- Síndrome -- um conjunto de anomalias que apresentam uma origem em comum mas que não se desenvolvem de forma sequencial.
- Associação -- anomalias congênitas de diferentes origens que se apresentam em conjunto numa frequência maior que o esperado para combinações ao acaso.
- Anomalias congênitas múltiplas -- presença de duas ou mais anomalias congênitas maiores que não são relacionadas, ocorrem ao acaso.

Anomalias congênitas de interesse para o médico generalista:

- [[atresia de esôfago]]
- [[hipospádias]]
- [[onfalocele]]
- [[gastrosquise]]
- [[anomalias do desenvolvimento sexual]]