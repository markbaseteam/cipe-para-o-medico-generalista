---
title: "Onfalocele"
---

### Conceito

A onfalocele, também conhecido com exonfalia, é um defeito de linha média reconhecido pela herniação de tamanho variável de vísceras abdominais recobertas por uma membrana. 

Esta membrana internamente e recoberta pelo peritônio, externamente pela membrana amniótica e entre estes por geleia de Wharton.

### Embriologia
 
Durante o período embrionário parte das vísceras abdominais se desenvolve fora da cavidade peritonial que ainda se encontra em formação. <small>ver também [[gastrosquise#Embriologia|embriologia na gastrosquise]].</small>

O intestino médio retorna gradualmente a cavidade abdominal realizando um giro de 270<sup>0</sup> graus sobre seu próprio eixo durante a 12<sup>a</sup> semana de desenvolvimento. A onfalocele ocorre quando este não retorna a cavidade abdominal. Mantendo defeito de tamanho variável a depender da presença de outras vísceras no defeito, principalmente o fígado.

Junto a isto o fechamento das dobras craniais e caudais dos folhetos do embrião também influenciam na morfologia do defeito. Alterações na dobra do folheto cranial desvia a onfalocele para o epigástrio e em suas formas mais graves pode ocorrer a _pentalogia de Cantrell_ (onfalocele associada a cardiopatia, _cleft_ esternal, diafragmático (hérnia) e pericárdico). Quando ocorre na dobra do folheto caudal pode vir associada a extrofia de bexiga ou de cloaca.

### Epidemiologia

Diferente da [[gastrosquise]] os casos de onfalocele tem se mantido estáveis ao longo dos anos com uma incidência de 1.5 a 3.0 por 10.000 nascidos vivos.

### Anomalias associadas

- Diferente da [[gastrosquise#Diagnóstico e anomalias associadas|gastrosquise]]. As anomalias associadas na onfalocele são muito mais frequentes (50%-70%).
- Anomalias cromossômicas (trissomia do 13, 14, 15, 18 e 21) estão presentes em até 30% dos casos
- Malformações cardíacas também são frequentes e ocorrem em 30% a 50% dos casos.
- Anomalias múltiplas e síndromes são comuns. <small>ver diferença em [[congenitas#Clínica|formas clínicas das anomalias congênitas]].</small>
- [[Beckwith Wiedemann]] está presente em até 10% dos pacientes.

### Diagnóstico

O diagnóstico pré-natal também pode ser realizado com a alfa feto proteína que se encontra elevada mas não tanto quanto as da [[gastrosquise]]. O que diminui a sensibilidade do método. 

A ultrassonografia após o primeiro trimestre é capaz de diagnosticar e diferenciar a [[gastrosquise]] da onfalocele na maioria dos casos. Isso permite o aconselhamento da família, o seguimento obstétrico e o encaminhamento da gestante para um hospital capacitado no atendimento a estes pacientes.

O primeiro passo após o diagnóstico é continuar a pesquisa diagnóstica de outras malformações incluindo ecocardiografia fetal e determinação cromossômica. 

O feto com onfalocele tem alto risco de restrição do crescimento intrauterino (5%-35%), parto prematuro (5%-60%) e óbito fetal intrauterino.

### Tratamento

O atendimento inicial ao paciente com onfalocele se inicia na [[reanimação neonatal]]. A hipoplasia pulmonar, prematuridade e malformações cardíacas comuns na onfalocele podem levar a intubação orotraqueal logo após o nascimento.

Toda reanimação neonatal aborda a verificação dos níveis de glicose, mas pode ser de particular importância no paciente com gastrosquise pela incidência aumentada de casos associados de [[Beckwith Wiedemann]], restrição do crescimento intrauterino e prematuridade.

A conduta no defeito está relacionado a manutenção da sua integridade no período pré-operatório e durante o um eventual transporte isso pode ser conseguido com curativo simples com gaze e uma atadura de crepom. Colocada de maneira que não comprima o defeito causando dificuldade respiratória ou compressão dos grandes vasos.

O tratamento cirúrgico definitivo irá depender:

- do tamanho do defeito,
- do estado clínico do paciente, 
- e das malformações associadas. 
 
Nos casos de onfalocele gigante pode ser necessário o fechamento escalonado do defeito. 
- Devido a anatomia (pela possibilidade de torções (_kinks_) de grandes vasos  que podem ocorrer devido a rotação do fígado na direção da cavidade abdominal.
- E devido ao aumento da pressão intra-abdominal e consequente hipertensão abdominal/síndrome compartimental abdominal.





