---
title: "Síndrome de Beckwith-Wiedemann"
---

Beckwith-Wiedemann é a associação de:
- macroglossia
- organomegalia
- hipoglicemia (hiperplasia pancreática com aumento dos níveis séricos de insulina)
- aumento do risco para tumores na infância (tumor de Wilms, hepatoblastoma e neuroblastoma).
