---
title: "Gastrosquise"
---

## Definição

- É um defeito completo da parede abdominal.
- Localizado do lado direito de um cordão umbilical normalmente implantado. 
- Não é recoberta por membrana ou saco. <small>ver também [[onfalocele]]</small>.
- Apresenta exposição de quantidade variável de alças intestinais ou outras vísceras mais raramente.
- O líquido amniótico em contato com as alças intestinais levam a um processo inflamatório (_serosite_) 
- A _serosite_ deixa as alças friáveis e endurecidas o que aumenta a chance de lesões durante a colocação das mesmas na cavidade abdominal.

## Embriologia

- No final da sexta semana de vida embrionária o embrião consiste em um disco plano com três camadas superpostas, endoderma, mesoderma e ectoderma. 
- Na sexta semana, a parede abdominal se forma pela dobradura dos folhetos cranial, caudal e laterais. Assumindo assim uma forma cilíndrica. 
-  Concomitante a este processo de fechamento da cavidade abdominal o intestino primitivo também se desenvolve ocupando o espaço no interior do cordão umbilical. 
- Em torno da 12 semana a cavidade abdominal já quase completamente formada recebe o intestino de volta através do anel umbilical. 

A causa da gastrosquise é desconhecida. Existem várias hipóteses para a sua ocorrência:

- defeito localizado na formação do mesoderma.
- ruptura do âmnio no anel umbilical.
- involução anormal da artéria umbilical direita.
- alterações na artéria vitelínica direita o que levaria a isquemia localizada na parede abdominal e defeito na dobradura dos folhetos na sexta semana.

## Epidemiologia

Apesar de variações regionais a incidência de gastrosquise tem aumentando no mundo inteiro. Em áreas endêmicas é cerca de 3 a 4 por 10.000 nascidos vivos. Nos últimos anos se tornou a anomalia congênita mais comum da parede abdominal. Se apresentam mais frequentemente em filhos de mães jovens (<20anos).

## Diagnóstico e anomalias associadas

- O diagnóstico da gastrosquise é na maior parte das vezes realizado por ultrassonografia pré-natal.
- A ultrassonografia tem alta especificidade, mas sensibilidade variável devido os defeitos da parede abdominal não serem pesquisados rotineiramente nos exames obstétricos.
- Alfa feto proteína se encontra elevado no sangue das mães de pacientes com gastrosquise.
- Cerca de 10% a 20% dos fetos com gastrosquise possuem malformações associadas.
- __A grande maioria das malformações associadas são no trato gastrointestinal.__
- Dez por cento das malformações associadas são estenoses ou atresias intestinais.
- Estas ocorrem devido a redução do fluxo sanguíneo através dos vasos intestinais devido a compressão durante a passagem por um anel umbilical estreito.

## Tratamento  

A conduta nos pacientes diagnosticados no pré-natal são as seguintes:

- ultrassonografia a cada 3 semanas com avaliação das condições das alças intestinais, crescimento fetal, líquido amniótico.
- medir batimentos cardíacos fetais (BCF) e movimentos fetais 1x por semana até a trigésima segunda semana  em caso de alterações ultrassonográficas e a partir daí 2x por semana em todos os casos.
- parto a termo ou o mais próximo possível do termo
- sem contraindicação para parto vaginal desde que as condiçoes maternas e fetais o permitam.

A conduta após o nascimento deve ser no sentido de manter a estabilidade hemodinâmica, respiratória e a viabilidade das alças intestinais.

- O prognóstico do paciente é dependente das malformações intestinais associadas e do cuidado intensivo no período pós-operatório.
- O tratamento se inicia com os procedimentos de reanimação neonatal.
- A gastrosquise aumenta a probabilidade de desidratação devido as perdas aumentadas na superfície intestinal exposta.
- Existe risco de hipoglicemia e outros distúrbios hidroeletrolíticos e ácidos básicos principalmente nos pacientes que apresentem restrição do crescimento intrauterino, baixo peso ao nascer ou prematuridade.
- O cuidado com as alças até o tratamento cirúrgico definitivo é essencial para a manutenção da viabilidade das alças intestinais.
- As alças intestinais devem ser recobertas com plástico transparente estéril para reduzir as perdas insensíveis e permitir a visualização da perfusão intestinal.
- Isso pode ser conseguido colocando o bebê dentro de uma bolsa plástica até a transição entre tórax e abdome. Ou envolvendo o abdome em plástico retangular.
- O aspecto das alças deve ser avaliado pelo médico continuamente. 
- O paciente deve ser colocado em berço aquecido.
- O paciente deve ser colocado em decúbito lateral direito e as alças apoiadas em compressas ou gazes de maneira que mantenham uma perfusão adequada até o tratamento definitivo

## Prognóstico

- A sobrevida da gastrosquise é de 90% a 95%.
- A maioria das mortes decorrem de complicações relacionadas a grandes ressecções intestinais e infecciosas.
- A internação é prolongada somente 40% dos pacientes recebem alta antes de 30 dias. Trinta e seis por cento de 30 dias a 60 dias. E 25% recebem alta somente após dois meses de internação.
- A maior parte do tempo internado o paciente passa tentando tolerar a dieta oral completa ou lidando com complicações relacionadas a intestino curto.
- 

