---
layout: page
title: "Meu bebê precisa de cirurgia"
permalink: /bebe-cirurgico
---

## Meu bebê precisa de cirurgia

Por onde começar:

- [[congenitas|anomalias congênitas]]
- [[onfalocele]]
- [[gastrosquise]]
- [[hipospádias]]

Objetivos:

- saber identificar e conduzir os casos diagnosticados com anomalias congênitas.
- identificar sinais de alerta, gravidade e conduta no transporte de crianças com [[congenitas|anomalias congênitas]].
- saber aconselhar os pais sobre risco e prognóstico de crianças com malformações congênitas
