---
title: "Anomalias congênitas prioritárias para a vigilância ao nascimento"
---

### Defeitos de Tubo Neural

- Q00.0 Anencefalia
- Q00.1 Craniorraquisquise
- Q00.2 Iniencefalia
- Q01 Encefalocele
- Q05 Espinha bífida

### Microcefalia 

- Q02 Microcefalia

### Cardiopatias Congênitas

- Q20 Malformações congênitas das câmaras e das comunicações cardíacas
- Q21 Malformações congênitas dos septos cardíacos
- Q22 Malformações congênitas das valvas pulmonar e tricúspide
- Q23 Malformações congênitas das valvas aórtica e mitral
- Q24 Outras malformações congênitas do coração
- Q25 Malformações congênitas das grandes artérias
- Q26 Malformações congênitas das grandes veias
- Q27 Outras malformações congênitas do sistema vascular periférico
- Q28 Outras malformações congênitas do aparelho circulatório

### Fendas Orais

- Q35 Fenda palatina
- Q36 Fenda labial
- Q37 Fenda labial com fenda palatina

### Anomalias de Órgãos Genitais

- Q54 Hipospádia
- Q56 Sexo indeterminado e pseudo-hermafroditismo

### Defeitos de Membros

- Q66 Deformidades congênitas do pé
- Q69 Polidactilia
- Q71 Defeitos, por redução, do membro superior
- Q72 Defeitos, por redução, do membro inferior
- Q73 Defeitos por redução de membro não especificado
- Q74.3 Artrogripose congênita múltipla

### Defeitos de Parede Abdominal

- Q79.2 Exonfalia
- Q79.3 Gastrosquise

### Síndrome de Down 

- Q90 Síndrome de Down

### VACTERL

Para a cirurgia pediátrica são de importância as malformações que ocorrem como a sequência __VACTERL__.

- __V__értebras -- fusões de vértebras, hemivértebras, vértebras em asa de borboleta.
- __Â__nus -- anomalia ano-retal.
- __C__ardíaca -- estenose pulmonar, defeitos de septo, hipertensão pulmonar.
- __T__raqueais -- CHAOS (_Congenital high airway obstruction syndrome_)
- __E__sofágicas -- [[atresia de esôfago]]
- __R__enais -- fusão, distopias renais, [[estenose da JUP]]
- __L__imbs (Membros) -- agenesia de rádio, pé torto, sindactilias
