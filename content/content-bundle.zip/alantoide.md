---
title: "Alantoide"
---

### Definição

Membrana embrionária, formada a partir do intestino posterior, que serve para a respiração e excreção nos embriões de répteis e aves; nos mamíferos constitui parte do cordão umbilical e une-se com o cório para formar a placenta. No ser humano representa o ligamento umbilical mediano. E pode persistir em formas de seios, fístulas ou cistos.