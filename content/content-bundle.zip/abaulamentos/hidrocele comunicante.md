---
title: "Hidrocele"
---

### Definição

A hidrocele é uma coleção fluida localizada entre as camadas da túnica vaginal, membrana que envolve o testículo. Ela pode ser: 

- Comunicante, quando o [[conduto peritônio-vaginal]] se mantêm pérvio e permite a livre passagem deste fluido de volta a cavidade peritonial.
- Não-comunicante, encistada ou **cisto de cordão espermático** quando o [[conduto peritônio-vaginal]] se fecha distal e proximalmente e sequestra o fluido no meio, desde o anel inguinal até a bolsa escrotal.

### Diagnóstico

Na maioria das vezes os pais referem o aparecimento de um caroço ou abaulamento na região inguinal ou a certa altura da bolsa escrotal até a região inguinal. O examinador deve ter atenção ao fato de que uma [[hérnia inguinal]] pode estar presente de forma concomitante, principalmente se a hidrocele for do tipo comunicante. Alguns pacientes podem vir ao pronto-socorro com queixa de uma massa cistíca endurecida, __indolor__, arredondada  que se estende até o canal inguinal se assemelhando a uma  [[hérnia inguinal]] encarcerada.

Uma característica das hidroceles é o seu crescimento lento e aumento progressivo ao longo do tempo. Episódios de aparecimento agudo de hidroceles podem ocorrer em casos de escroto agudo como a [[torção do testículo]] e de seus apêndices. Outra situação que propicia o aparecimento de hidroceles são processos inflamatórios e infecciosos abdominais e respiratórios na criança. Que levam a aumento na produção e acúmulo de liquido peritonial, este então flui através de um [[conduto peritônio-vaginal]] previamente não identificado apresentando as manifestações clínicas da hidrocele.

As hidroceles podem ser diferenciadas das hérnias inguinais clinicamente através da palpação de um testículo flutuante em uma fase líquida que também pode ser observada pela trans iluminação. Esta não garante o diagnóstico de hidrocele uma vez que uma alça intestinal encarcerada preenchida com gás também pode simular os achados da trans iluminação da hidrocele. __Devido a isso a punção diagnóstica nunca deve ser tentada.__

### Tratamento

O tratamento da hidrocele é cirúrgico. Como a maioria das hidroceles serão reabsorvidas até os dois anos de vida é comum se esperar até a criança atingir essa idade para se indicar o tratamento. A não ser nos casos onde não se pode excluir uma [[hérnia inguinal]] concomitante ou nos casos de hidroceles comunicantes onde se é sabido que o [[conduto peritônio-vaginal]] está pérvio. Nesta situação se considera a hidrocele como uma persistência do conduto peritônio-vaginal e se procede o tratamento cirúrgico de maneira análoga ao da [[hérnia inguinal]].


