---
title: "Escroto Agudo"
---

## Causas


- [[torção do testículo|Torção do testículo]]
	- intravaginal
	- extravaginal
- Torção do apêndice testicular
- Epididimite
- Orquite por parotidite
- Edema escrotal idiopático
- Necrose da gordura escrotal

### Torção testicular

#### intravaginal

Pouco frequente, ocorre no período neonatal.

#### extravaginal

Muito frequente, pode ocorrer em qualquer idade, mas é mais comum na puberdade. Quando se acredita que os efeitos tróficos dos androgênios possam facilitar a torção mecanicamente.

### Torção do apêndice testicular

Muito frequente , pico de incidência aos 11 anos de idade.

### Epididimite

Raro de acontecer, mais frequente nos primeiros 6 meses de vida, geralmente por ascensão de enterobactérias, principalmente a _E. coli_ pela uretra e ducto deferente.

### Orquite por parotidite

Incomum e __só ocorre após a puberdade__.

### Edema escrotal idiopático

Muitas vezes confundida com a torção de testículo. O paciente apresenta edema, dor e eritema em região escrotal que se continua em direção a região inguinal, pênis ou períneo. A causa pode ser estrófulo alérgico, impetigo, ectima ou celulite. Presente dos 0 aos 5 anos.

### Necrose da gordura escrotal

Observa-se o aparecimento súbito de pequenas protuberâncias em ambos os lados acompanhado de dor e eritema. __Raro__, ocorre geralmente em pacientes obesos após submersão em água gelada, 5 aos 15 anos. 
