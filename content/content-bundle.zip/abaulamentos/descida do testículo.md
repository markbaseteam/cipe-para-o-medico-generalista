---
title: "Descida do testículo"
---

### Embriologia da descida do testículo

<figure>
{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696418/garden/notas-cipe/embriologia_criptorquidia.png %}
<figcaption>Netter, 2011</figcaption>
</figure>

O processo de descida testicular é um processo complexo que ocorre em fases no período embrionário e se estende até o nascimento e ainda não é conhecido em sua totalidade. A descida testicular pode ser dividida em duas fases:

- Fase trans-abdominal (8-15 semanas de idade gestacional)
- Fase ínguino-escrotal (28-35 semanas de idade gestacional)

#### Fase trans-abdominal

Neste período ocorre a diferenciação sexual do feto humano incluindo o desenvolvimento do testículo que se encontra preso em sua posição superiormente pelo ligamento suspensor do ovário e inferiormente pelo _gubernaculum_ sob estímulo da testosterona o ligamento suspensor regride e desaparece no sexo masculino. O _gubernaculum_ que em uma extremidade está conectada ao testículo tem sua porção mais distal junto a parede antero-lateral do abdome. Esta última parte se alarga e se torna espessada sob influência principalmente da _insulin like 3_, um membro da família de hormônios do crescimento semelhantes à insulina. Neste processo também estão envolvidos a testosterona e o fator inibidor mülleriano.

#### Fase inguino-escrotal

A transição do _gubernaculum_ e testículo do canal inguinal até o escroto é orquestrado pelos andrógenos. No entanto o nervo genito-femoral e a liberação por parte dele de um peptídeo relacionado ao gene da calcitonina (CGRP) também parecem influenciar o processo de crescimento do gubernáculo em direção à bolsa escrotal. Outros fatores mostrado em modelos animais são:

- a pressão intra-abdominal aumentada que exerce força sobre o testículo no sentido da bolsa escrotal
- as contrações do músculo cremaster presente em torno do _gubernaculum_

Qualquer anomalia que perturbe o processo de descida testicular provoca uma doença chamada [[testículo não-descido]].

A perviedade do [[conduto peritônio-vaginal]] após o nascimento pode acarretar o aparecimento de [[hérnia inguinal]] e [[hidrocele comunicante|hidroceles]].
