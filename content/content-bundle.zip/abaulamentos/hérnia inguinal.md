---
title: "Hérnias Inguinais"

author: "Daniel Rangel"
---

### Introdução

Doença conhecida desde a antiguidade. É a cirurgia mais comumente realizada por cirurgiões pediátricos.

### Epidemiologia

Tem uma incidência que varia de 0,8% a 4%. A maior parte dos diagnósticos são realizados no primeiro ano de vida sendo 1/3 das cirurgias realizadas nos primeiros seis meses de vida. Até 1/4 dos prematuros apresentam hérnias inguinais o que se correlaciona com a perviedade do _processus vaginalis_ neste período. Ao nascer até 80% das crianças apresentam perviedade do _processus vaginalis_ e todas as hérnias inguinais indiretas ocorrem por algum defeito no fechamento deste.

- Os meninos são mais acometidos em razão que varia de 3:1 até 10:1.
- As hérnias são mais comuns a direita (60%) que a esquerda (30%) e 10% são bilaterais.
- Nos prematuros a bilateralidade pode chegar a 40%.

Os pacientes portadores de hérnia inguinal podem apresentar complicações como encarceramento e estrangulamento herniário em 15% dos casos e quando isto ocorre, acontece mais frequentemente (70%) antes de um ano de vida.

### Embriologia

As hérnias inguinais são secundárias a persistência do _processus vaginalis_ ou [[conduto peritônio-vaginal]]. Uma protrusão do peritônio que liga a cavidade peritoneal com a cavidade vaginal na bolsa escrotal no menino. O que corresponde ao canal de Nuck nas meninas que liga o peritônio aos grandes lábios e regride em torno do sétimo mês de gestação. Apesar de sua perviedade ser um pré-requisito para a formação da hérnia inguinal sua presença por si só não é suficiente para a formação desta última. Afirmação confirmada por achados desta perviedade em até 100% em algumas séries de casos em pacientes que não apresentam hérnia inguinal indireta.

### Diagnóstico

As hérnias inguinais geralmente são observadas pelos pais como um abaulamento inguinal, escrotal, nos grandes lábios ou na virilha, durante o banho ou durante aumentos da pressão intra-abdominal como choro ou esforço físico. Durante a anamnese é importante tentar diferenciar estes abaulamentos de outros presentes em pacientes com [[hidrocele comunicante]], [[testículo não-descido]]. Alguns fatores congênitos que aumentam a pressão intra-abdominal ou dificultam o fechamento do _processus vaginalis_ podem ajudar, são eles: 

#### Fatores de Risco para Hérnias

- Extrofia Vesical
- Ascite
- Diálise peritonial
- Derivação ventrículo-peritonial 
- Gastrosquise, Onfalocele
- Fibrose cística
- Luxação congênita do quadril
- [[testículo não-descido|Testículo não-descido]]
- [Síndrome de Ehlers-Danlos](https://pt.wikipedia.org/wiki/S%C3%ADndrome_de_Ehlers-Danlos)
- [Síndrome de Marfan](https://pt.wikipedia.org/wiki/S%C3%ADndrome_de_Marfan)
- [Síndrome de Hunter-Hurler](https://en.wikipedia.org/wiki/Hurler_syndrome)
- [Mucopolisacaridoses](https://en.wikipedia.org/wiki/Mucopolysaccharidosis)

O exame físico basicamente consiste na inspeção e palpação da região inguinal. Com o paciente despido em posição supina em uma maca deve-se procurar por abaulamentos e assimetrias na região inguinal, escrotal e grandes lábios nos casos das meninas. A palpação se inicia com a captura do testículo entre os dedos indicador, médio e polegar da mão direita do examinador e palpação do canal inguinal junto ao tubérculo púbico a procura do cordão espermático com os dedos indicador e médio da mão esquerda. Deve-se tentar perceber a espessura deste e compará-la com o lado contra-lateral. O sinal da _luva de seda_ consiste da sensação de duas superfícies deslizando uma sobre a outra lembrando o aspecto da indumentária que leva seu nome. Nas crianças maiores sempre que possível colocá-las em posição ortostática e tentar realizar a manobra de Valsalva.

### Complicações

A principal complicação é o encarceramento herniário, momento onde ocorre a protrusão do conteúdo hernário e seu sequestro impedindo o retorno à cavidade abdominal. Nesta situação os principais sintomas são relacionados a obstrução intestinal que ocorre em consequência. Eventualmente este encarceramento pode levar a isquemia e necrose do conteúdo herniado. Essas situações são evitáveis em até 90% dos casos quando a hérnia é tratada cirurgicamente até 30 dias após o diagnóstico.

### Tratamento

O tratamento da hérnia inguinal na criança é cirúrgico. O momento correto de se indicar o tratamento cirúrgico é assim que  realizado o diagnóstico e as condições clínicas do paciente permitirem o procedimento. Os recém-nascidos e prematuros podem ser operados 48h antes da alta hospitalar após o nascimento devido aos efeitos deletérios de complicações como o encarceramento e estrangulamento.

O tratamento cirúrgico é a herniorrafia por via inguinal (sutura do saco herniário). É realizada uma incisão transversa na região inguinal até a aponeurose do musculo oblíquo externo a qual é aberta do anel inguinal externo até o anel inguinal interno expondo todo o canal inguinal. O funículo espermático é identificado e isolado no canal inguinal e a fáscia cremastérica é aberta, o saco herniário dissecado separando-o dos vasos testiculares e do deferente no menino e do ligamento redondo na menina. O saco herniário é então ligado com sutura transfixante de fio absorvível na sua base junto à gordura pré-peritoneal. No caso de hérnias grandes onde há alargamento do anel inguinal profundo pode se fazer um reforço unindo-se a fáscia _transversalis_ ao ligamento íleo pectíneo (técnica de Zimmerman) ou o tendão conjunto ao ligamento inguinal posteriormente ao cordão espermático (técnica de Bassini). A incisão é fechada por camadas e a sutura da pele é feita com pontos subcuticulares de fio absorvível.

Não há necessidade de exploração contralateral em pacientes que não apresentem sinais ou sintomas de hérnias. Exceção se faz aos pacientes que apresentam alto risco anestésico/cirúrgico, alta incidência de bilateralidade ou [fatores de risco para hérnia inguinais](#fatores-de-risco-para-hérnias).

A hérnia estrangulada é uma emergência cirúrgica e deve ser operada imediatamente, o termo significa que houve necrose e perda permanente de conteúdo herniado. Via de regra essas hérnias são irredutíveis mesmo após manobras forçadas. 

A hérnia encarcerada é aquela que não reduz espontaneamente e mesmo nas mãos de um examinador experiente pode apresentar dificuldades principalmente quando realizada na presença dos pais ou sem analgesia adequada. Em caso de dúvidas sobre a viabilidade do conteúdo herniado ou se a hérnia não pode ser reduzida considerar como uma hérnia estrangulada e operar imediatamente para reduzir o dano ao conteúdo que se encontra isquêmico. Mesmo nos casos em que a hérnia encarcerada pode ser reduzido a melhor conduta é a internação para reduzir o edema dos tecidos e observar a viabilidade do conteúdo que foi reduzido e corrigir a hérnia em 48h na mesma internação.

Nos pacientes que são operados por complicações da hérnia, convém tracionar e examinar o testículo pela incisão inguinal com o intuito de diagnosticar orquite isquêmica secundária a compressão dos vasos testiculares pelo conteúdo herniário. Em alguns casos pode haver necrose do testículo e ser necessário orquiectomia o que deve ser avisado aos pais antecipadamente. Nas meninas com ovário encarcerado estes achados também podem ocorrer.

Como complicações do tratamento cirúrgico pode ocorrer recidivas em 0,1% a 1% dos casos, infecção de ferida operatória em 1%, lesão do ducto deferente, hematomas e edema da região inguinal, criptorquidia iatrogênica, hipotrofia testicular em 10% a 15%, ressecção de alças em 10%.








