---
title: "Torção de testículo"
---

A torção de testículo é um problema comum no pronto socorro de cirurgia pediátrica, ocorre devido a uma anomalia na fixação do testículo na túnica vaginal do escroto. O que leva a redução do fluxo sanguíneo para o testículo e, se não tratado, isquemia e necrose.

### Fisiopatogenia

A torção pode ocorrer de duas maneiras:

- intravaginal
- extravaginal

#### Intravaginal

Normalmente o testículo permanece fixo em sua posição na cavidade vaginal do escroto por uma prega de túnica vaginal que se origina na superfície posterior desta e se estende posteriormente ao testículo na sua relação com o epidídimo, recobrindo ambos lateralmente até a borda anterior e retornando medialmente a estes. 

Desta forma a borda posterior do testículo e seu epidídimo ficam presos a parede posterior da bolsa escrotal permitindo a mobilidade do testículo mas não sua torção. A anomalia de fixação ocorre quando está prega se forma precocemente durante o período de [[descida do testículo]] fazendo com que o mesmo fique suspenso dentro da bolsa escrotal de maneira semelhante a úvula ou o badalo de um sino. 

Assim podendo ocorrer a torção do mesmo e a interrupção do fluxo sanguíneo através dos vasos testiculares.

#### Extravaginal

É restrita ao período neonatal durante a [[descida do testículo]] o *gubernaculum* traciona o testículo através do [[conduto peritônio-vaginal]]. 

Na interface entre as estruturas que se movimentam e o conduto fixo que elas atravessam existe uma camada frouxa de tecido conjuntivo que permite todo o conjunto (*gubernaculum* e testículo) torcer. Causando isquemia e necrose do testículo. 

Quando este evento ocorre ainda no período fetal pode levar a reabsorção do testículo e ausência do mesmo após o nascimento com os vasos gonadais e ducto deferente terminando em fundo cego no peritônio intra-abdominal, quadro denominado de *vanishing testis*.

### Epidemiologia 

 - Torção testicular é mais comum durante a puberdade. 
 - O período neonatal também apresenta um pico de incidência.
 - Na infância pensar em torção dos anexos testiculares como o apêndice de _Morgagni_ que se localiza na cabeça do epidídimo.

<small>Ver causas de [[escroto agudo]].</small>

### Quadro clinico 

O principal sintoma é o início súbito de do testicular com irradiação para região inguinal ou hipogástrio. Pode acontecer náusea e vômito. 

A bolsa escrotal do lado acometido apresenta sinais flogísticos. E é comum o testículo se apresentar aumentado de volume durante o exame físico que via de regra é bastante doloroso.

Quando há necrose a cor da bolsa pode ser tornar arroxeada e quando essa cor é vista em formato de ponto ou grão de arroz no polo superior do testículo a hipótese de torção do apêndice de _Morgagni_ deve ser considerada.

Acúmulo de liquido em torno do testículo (_hidrocele_) pode ocorrer de forma reacional.

Os exames complementares como ultrassonografia com _doppler_ ou cintilografia para pesquisa de fluxo sanguíneo no parênquima testicular podem ser solicitados. Deve-se levar em conta que os testículos pós-puberais são mais volumosos o que se reflete em melhor acurácia desses exames em diferenciar situações de __ausência de fluxo__ (torção) de situações de __aumento de fluxo__ (orquite). 

Desta forma alguns cirurgiões preferem a indicação de exploração da bolsa escrotal em todos os pacientes. Independente do resultado dos exames complementares.

### Tratamento

Cirurgia para exploração da bolsa escrotal de urgência. O testículo contralateral deve sempre ser explorado quando encontramos uma torção testicular. A malformação que levou a torção de um lado provavelmente está presente do outro lado. 

O testículo necrosado exige a _orquiectomia_. Ainda é motivo de discussão a remoção do testículo de viabilidade duvidosa. Alguns cirurgiões optam pela _orquiectomia_ enquanto outros pela manutenção do testículo e sua _orquidopexia_. Com a finalidade de reduzir a pressão no parênquima testicular alguns cirurgiões realizam uma incisão na túnica albugínea. 





