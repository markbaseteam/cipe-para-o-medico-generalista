---
layout: page
title: "Abaulamentos inguinais e escrotais"
permalink: /abaulamentos
---
## Abaulamentos inguinais e escrotais

Os abaulamentos na região inguinal da criança é um problema comum e causado pelas diversas formas de apresentação das persistências do [[conduto peritônio-vaginal]] após o processo de [[descida do testículo]]. Outras causas são [[tumor testicular|tumores]] e as causas de [[escroto agudo]].

Outras notas de interesse nesse tema:

- [[conduto peritônio-vaginal]]
- [[hérnia inguinal]]
- [[hidrocele comunicante]]
- [[testículo não descido|testículo não-descido]]

### Objetivos

#### Saber

- o que é e como diferenciar hérnias e hidroceles
- quais são as causas de abaulamento inguinal e como se trata.
- como reconhecer os sinais que estão presentes em situações de urgência e como proceder.
- como diagnosticar a criança com testículo não palpável.
- quais as consequências da criança com testículo não palpável que não é tratada adequadamente.
- reconhecer hérnias abdominais de interesse clínico na criança.

