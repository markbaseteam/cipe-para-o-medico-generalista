---
alias: criptorquidia
permalink: criptorquidia
title: "Testículo não-descido"
---

### Histórico

O testículo não-descido é conhecido desde a antiguidade. No entanto o mecanismo de descida testicular não era conhecido ate 1786 quando [John Hunter](https://en.wikipedia.org/wiki/John_Hunter_(surgeon)), dissecou um feto humano e percebeu um testículo aderido a parte interna da parede abdominal.

### Epidemiologia

A [[descida do testículo]] é um processo complexo que ocorre em múltiplos estágios. Qualquer anormalidade na migração do testículo e na formação do _gubernaculum_ e do [[conduto peritônio-vaginal]] pode levar a ectopias testiculares. 
> <header>Incidência do Testículo não-descido<header>
> Após o nascimento é cerca de 4%. No entanto, após o terceiro mês de vida essa incidência cai para 1-2%. 

A descida testicular não se completa até a 35ᵃ semana da gestação. Além disso, são fatores de risco para testículo não-descido: 
- prematuridade;
- restrição do crescimento intra-uterino;
- baixo peso ao nascer.

Nos pacientes com fatores de risco a incidência pode ser de até 70%. Este número de diminui a medida que o RN se desenvolve e atinge a idade pós-natal de termo. 

Por exemplo: uma criança que nasceu com 35 semanas de idade gestacional. E tem 5 semanas de idade cronológica (de vida após o nascimento). Consideramos que ele tenha 40 semanas de idade corrigida. Isso implica em diferenças nos marcos do desenvolvimento, risco para doenças (apnéia) e risco para efeitos adversos na anestesia.

### Diagnóstico

O diagnóstico é clínico e realizado durante a palpação da bolsa escrotal que se encontra vazia. Continuando a palpação da região inguinal podemos classificar o testículo não-descido como:

>- **testículo não palpável ou criptorquidia**, quando não conseguimos palpá-lo ou mesmo saber se existe testículo.
>- **testículo palpável**, quando conseguimos localizar o testículo no canal inguinal.
>- **testículo ectópico**, localizado na raiz da coxa, períneo, região supra-púbica ou no lado contra-lateral (raro)
>- **testículo retrátil** que é um testículo palpável na região inguinal mas não fixo o que implica que o mesmo desce com facilidade durante as manobras de tração e permanece na bolsa escrotal após estas.
>-  **testículo não-descido tardio** é aquele que ao nascimento é palpável na bolsa escrotal e posteriormente deixa de ser.

O _testículo retrátil_ acontece devido ao **reflexo cremastérico**. O músculo cremaster ou camada espermática média do funículo espermático se contrai e traciona o testículo na direção ao canal inguinal, assim não conseguimos palpar o mesmo na bolsa escrotal mas conseguimos tracioná-lo para a mesma com facilidade. 

Este reflexo é desencadeado por medo, frio ou estímulo tátil da face interna da coxa e é comum ocorrer durante exame de ultrassonografia da bolsa escrotal ou do testículo levando a diagnósticos falso positivos. 

Um outro tipo de alteração ocorre quando durante consultas seguidas ao pediatra inicialmente é possível se observar e palpar o testículo na bolsa escrotal mas em consultas subsequentes não se palpa o testículo na bolsa escrotal. Este é classificado como **testículo não-descido tardio**.

### Tratamento 

O tratamento das distopias testiculares é com cirurgia. No testículo não palpável se realiza um procedimento chamado videolaparoscopia com intuito de se localizar o testículo e verificar a viabilidade de se tracionar e fixar o mesmo na bolsa escrotal, procedimento denominado __orquidopexia__. A orquidopexia também pode ser realizada por via inguinal nos casos em que conseguimos palpar o testículo neste local, dispensando o uso da videolaparoscopia. 

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651966742/garden/notas-cipe/conduta_tnd.jpg %}
