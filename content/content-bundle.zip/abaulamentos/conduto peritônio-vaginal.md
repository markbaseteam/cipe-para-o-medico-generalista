---
title: "Conduto peritônio-vaginal"
---

O conduto peritônio-vaginal ou _processus vaginalis_ é uma estrutura anatômica relacionada ao _gubernaculum_ e envolvido na [[descida do testículo]] que ocorre no período embrionário e fetal. 

Alguns autores acreditam que sua formação decorre do aumento da pressão intra-abdominal neste período. Outros, no entanto, sugerem que sua formação é um processo ativo dependente de hormônios andrógenos e do crescimento como a diidrotestosterona (DHT) e a _insulin like 3_ (Insl3).

### Persistência do conduto peritônio-vaginal

<figure>
{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696347/garden/notas-cipe/conduto_peritonio_vaginal.png %}
<figcaption>formas de persistência do conduto peritônio-vaginal</figcaption>
</figure>


A persistência do conduto peritônio-vaginal após o nascimento pode causar várias doenças de tratamento cirúrgico. Na imagem acima se vê:
- A - **fechamento normal do conduto.**
- B - [[hidrocele comunicante|hidrocele não comunicante]].
- C - [[hidrocele comunicante]].
- D - [[hérnia inguinal]].
- E - [[hérnia inguinal|hérnia inguino-escrotal]].

Existe ainda a possibilidade de o conduto peritônio vaginal ser fechado em suas porções proximais e distais sequestrando líquido em seu trajeto sem no entanto manter comunicação nem com a cavidade peritonial, dando origem a hérnias, nem com a cavidade vaginal do testículo dando origem a hidroceles. Este tipo de alteração é chamada de _cisto do cordão espermático_ ou _hidrocele encistada_. 


