---
title: "Atresia das vias biliares"
permalink: "/avb"
---
{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652559704/garden/notas-cipe/avb_l1xn4z.jpg %}

### Conceito

A atresia das vias biliares (AVB) é uma doença de causa desconhecida que cursa com uma fibrose progressiva das vias biliares e se apresenta como [[colestase]] no período neonatal.

### Epidemiologia

Apesar de ser uma doença rara, 1 em cada 10000 a 20000 nascimentos. A atresia das vias biliares é a causa __cirúrgica__ mais comum de icterícia no RN. 

### Patogenia

A causa da AVB não é conhecida. No entanto, diversos fatores podem estar relacionados com o aparecimento da doença.

- Vírus
- Toxinas
- Genético
- Imunológico

### Diagnóstico

A  AVB tem uma apresentação clínica heterogênea

 - __AVB isolada__ é o tipo de apresentação mais comum (70% a 85% )em que o paciente não nasce ictérico e a desenvolve de forma progressiva e mantida ao longo dos primeiros dois meses de vida juntamente com acolia fecal.
- __AVB embrionária ou sindrômica__ é uma forma de mal prognóstico e vem acompanhada de _situs inversus_, asplenia ou poliesplenia, veia porta pré-duodenal, ausência de veia cava e anomalias cardíacas. 
- __AVB cística__ quando ocorre a obstrução biliar e o acúmulo de bile formando coleções císticas (bilioma) que podem infectar de forma secundária. Muitas vezes localizada no hilo hepático podem ser visualizadas na ultrassonografia de abdome. 
- __AVB associada a hepatite por CMV__ o paciente apresenta hepatite com icterícia e acolia fecal e sorologias positivas para CMV. O diagnóstico pode ser retardado devido ao diagnóstico e tratamento da infecção antes da suspeição da AVB. O que ocorre quando a acolia se mantém após o fim do tratamento da hepatite. 

A AVB também pode vir acompanhada de outras malformações [[anomalias congênitas prioritárias para a vigilância ao nascimento#VACTERL|congênitas]]. Atresias intestinais, anomalias anoretais, malformações renais ou cardíacas.

No início do quadro a criança apresenta icterícia, colúria e acolia fecal. Os níveis de bilirrubina direta se elevam progressivamente e após um período é possível começar a se observar sinais de insuficiência hepática e hipertensão portal.

A **icterícia** pode aparecer  na criança do nascimento até oito semanas. Raramente acontecendo após esse período. Se inicia na esclera e evolui de forma progressiva.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652551378/garden/notas-cipe/acolia_nwicg1.jpg %}

A **acolia fecal** ocorre de forma secundária a obstrução da via biliar. As fezes que caracteristicamente são _amarelo ouro_ se tornam esbranquiçadas e sem brilho adquirindo um aspecto de _massa de vidraceiro_. 

Valores de bilirrubina direta maiores que 1mg/dL nas primeiras 2 semanas de vida são extremamente sensíveis no diagnóstico da AVB. Podendo ser utilizado como um marcador de triagem para pacientes que apresentem [[colestase]] no período neonatal e possam necessitar da avaliação de um cirurgião pediátrico.

A hepatomegalia também é um sinal frequente durante o exame físico e é decorrente da toxicidade da bilirrubina que não esta sendo adequadamente drenada para o intestino. Esplenomegalia aparece mais tardiamente e deve levantar a suspeita de que o paciente já apresente sinais de hipertensão portal. Quando precoce nas primeiras semanas a esplenomegalia deve ser considerada como um marcador infeccioso e exclusão dos diagnósticos das [[TORCHS]]

A ultrassonografia pode mostrar uma imagem ecogênica de formato triangular entre os ramos da veia porta. Esta imagem chamada de __triângulo fibroso__(_triangular cord_) tem   especificidade de 95% para AVB e uma sensibilidade de 68%. Além disso outras causas de colestase neonatal podem ser excluídas ([[cistos de colédoco]], [[cálculos biliares]], dilatações da via biliar).

A biópsia hepática pode ser realizada para confirmar os achados histológicos de obstrução biliar:
- Expansão dos espaços porta
- Proliferação ductular marginal (nos espaços porta)
- Edema, inflamação e fibrose em torno dos espaços porta
- Plugues de bile intraductais

Esses achados não excluem outros diagnósticos de obstrução biliar, mas associados a clínica são típicos de AVB.

A colangiografia é o exame padrão ouro para o diagnóstico da obstrução das vias biliares. Pode ser realizada por endoscopia (CPRE), ressonância magnética, medicina nuclear e intraoperatória. A colangiografia intraoperatória é a melhor forma de realizar o diagnóstico definitivo e de maneira célere proceder o tratamento cirúrgico.

### Tratamento

> #### ⚠️ **Atenção!!**  
>
> É imprescindível que o paciente seja encaminhado o mais rapidamente possível para o cirurgião pediátrico ou serviço de transplante hepático. Os procedimentos para drenagem da via biliar no período neonatal são eficazes antes da 12<sup>a</sup> semana de vida. Exames complementares não devem atrasar a avaliação do paciente por um cirurgião.

Após uma colangiografia que demonstre a ausência de perviedade dos ductos biliares o procedimento de Kasai (_portoenterostomia_) deve ser realizado imediatamente. O objetivo do tratamento é a drenagem da via biliar para o intestino. Isto impede a lesão dos hepatócitos pela bile e reduz a chance de _cirrose biliar secundária_. 

