---
title: "Colestase"
---

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696591/garden/notas-cipe/bebe_azul.jpg %}

Colestase na infância é considerada como valores de bilirrubina direta/conjugada >1mg/dL e maior que 20% da bilirrubina total.
Nos pacientes que se alimentam ao seio materno e apresentam icterícia após duas semanas de vida e nos que se alimentam de fórmulas infantis e apresentam icterícia antes desse período deve ser solicitada bilirrubina sérica total e frações para se diferenciar a icterícia do aleitamento materno, muito mais comum e as custas de bilirrubina indireta da colestase que elevará a bilirrubina direta.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696387/garden/notas-cipe/colestase.jpg %}

### Causas

A colestase acontece em cerca de 1 para 2500 nascidos vivos e tem as principais causas listadas abaixo:

- Obstrução anatômica
  - [[atresia das vias biliares]], cistos de colédoco, colelitíase, bile espessada, perfuração espontânea dos ductos biliares, tumores.
- [Infecções][1]
  - Virais, bacterianas, espiroquetas e parasitas
- Toxinas
  - drogas, endotoxina, nutrição parenteral total
- Endócrino
  - Hipotireoidismo, hipopituitarismo
- Genético e erros congênitos do metabolismo
  - Deficiência de alfa-1-anti-tripsina ( SERPINA1 )
  - Síndrome de Allagile ( JAGGED1, NOTCH2 )
  - Fibrose cística ( CFTR )
  - Galactosemia ( GALT )
  - Tirosinemia tipo 1 ( FAH )
  - Colangite esclerosante neonatal ( DCDC2 )
  - Doença de Niemann Pick tipo C  ( NPC1, NPC2 )
  - _Progressive Familial Intrahepatic Cholestasis_ (PFIC)
- Outros
  - hepatite neonatal transitória, isquemia, hipóxia, congestão hepática

[1]: https://pt.wikipedia.org/wiki/Infec%C3%A7%C3%A3o#Sistemas_fechados_de_infus%C3%A3o "Infecções Wikipedia"
