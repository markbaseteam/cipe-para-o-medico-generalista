---
layout: page
title: "A criança ictérica"
permalink: /a-criança-ictérica
---
## A Criança com Icterícia

Por onde começar:

- [[atresia das vias biliares]]
- [[colestase]]
- [[cistos de colédoco]]

Objetivos:

- diferenciar icterícia que necessite de tratamento cirúrgico das de conduta clínica.
- identificar sinais, sintomas e alterações laboratoriais de redução da função hepática na criança.
- sinais de alerta, gravidade e conduta nas crianças com icterícia.
