---
---

Mnemônica para:

- Toxoplasmose
- Rubéola
- Citomegalovírus
- Hepatite
- Sífilis

