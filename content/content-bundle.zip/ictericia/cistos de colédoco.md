---
title: "Cistos de colédoco"
---

### Conceito

Cistos de colédoco são dilatações congênitas das vias biliares. Sua etiologia não é conhecida mas está comumente associada a malformações na junção dos ductos colédoco e pancreático principal.

### Classificação

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652561539/garden/notas-cipe/todani_tgc7a1.png %}

- A -- dilatação cística dos ductos biliares extra-hepáticos.
- B -- dilatação fusiforme dos ductos biliares extra-hepáticos.
- C -- dilatação frustra dos ductos biliares extra-hepáticos (_forme fruste_).
- D -- divertículo anexo aos ductos biliares extra-hepáticos.
- E -- coledococele (divertículo do colédoco distal)
- F -- dilatação intra-hepática dos ductos biliares (doença de Caroli).

### Diagnóstico

O paciente pode apresenta icterícia, massa abdominal em hipocôndrio direito e acolia fecal. No período neonatal a [[atresia das vias biliares]] é um diagnóstico diferencial importante. 

Na infância a criança pode ser trazida ao médico com história de quadros de icterícia febril (colangites) de repetição. Esses episódios evoluem com gravidade variada podendo ocorrer sepse grave com elevação de enzimas hepáticas e eventualmente insuficiência hepática secundária ao choque. 

### Exames complementares

A ultrassonografia é um excelente exame para se diagnosticar os cistos de colédoco. Além de serem úteis no diagnóstico diferencial no período neonatal.

A colangio ressonância magnética pode ser realizada de maneira complementar a ultrassonografia e para classificação e programação cirúrgica do paciente.

### Tratamento

O tratamento é a ressecção do cisto com ressecção da mucosa da porção distal e reconstrução com derivação bilio-digestiva em y-Roux.
