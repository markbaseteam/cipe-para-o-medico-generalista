---
layout: page
title: "Infecção urinária na infância"
permalink: /infecção-urinária
---

## Infecção urinária na infância

Quando não há o diagnóstico ultrassonográfico pré-natal de [[hidronefrose]], a [[infecção do trato urinário]] se torna o momento oportuno para se realizar o diagnóstico das mal-formações das vias urinárias.

### Objetivos

#### Saber

- o que é infecção urinária.
- como tratar e conduzir um caso de infecção do trato urinário na criança.
- que doenças de tratamento cirúrgico podem causar ou contribuir para infecção urinária na infância.
- como ocorre perda de função renal e como evitá-la.
- como interpretar e quando solicitar cintilografias renais, uretrocistografia e ultrassonografia.
