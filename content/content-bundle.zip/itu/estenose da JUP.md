---
title: "Estenose da junção uretero-piélica"
---

### Introdução

A estenose da junção uretero-piélica (EJUP) é a mais frequente causa de ==hidronefrose==. Com a disseminação da ultrassonografia como método de triagem neonatal a apresentação clínica mudou, a maioria dos pacientes são assintomáticos ao nascimento e já apresentam o diagnóstico pré-natal.

### Epidemiologia

A EJUP acomete cerca de 1 a cada 750-2000 nascidos vivos e é a causa mais comum de hidronefrose. Dos pacientes que apresentam hidronefrose no período antenatal, 13% são portadores de EJUP. A doença é mais comum em meninos que em meninas numa proporção de 2:1 e raramente acomete os dois rins.

### Fisiopatologia

