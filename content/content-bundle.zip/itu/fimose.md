---
title: "Fimose"
---

### Conceito
Estenose anatômica fixa do orifício prepucial que impede a retração do 3 sobre a glande do pênis. Pode fazer parte da própria conformação do prepúcio ou pode ser adquirido após múltiplos episódios infecciosos (_bálano-postites_) e com desenvolvimento de anel fibroso (_balanite xerótica obliterante_)

### Epidemiologia
Somente 4% dos recém-nascidos do sexo masculino apresentam prepúcio completamente retrátil ao nascimento. Esse número aumenta para 20% aos 6 meses de vida e 90% aos 5 anos. [^1] O processo de exteriorização da glande do pênis faz parte do desenvolvimento normal do genital masculino.

### Diagnóstico
É importante diferenciar fimose de acolamento bálano-prepucial. Este consiste em uma fina aderência do parte interna do prepúcio sobre a glande do pênis e ao longo do tempo devido ao acúmulo de esmegma na coroa glandar tende a se desfazer espontaneamente.

### Tratamento

O uso de córticoide tópico é efetivo em resolver a fimose alterando a constituição da pele. Associado ou não a exercícios de tração do prepúcio levam a alargamento e exposição completa da glande. No entanto não existe evidência suficiente comparando o uso de corticóide com a simples observação da evolução dos pacientes uma vez que a maioria irão se resolver espontaneamente. Também não existe literatura demonstrando as possiveis complicações decorrentes do uso deste medicamento nem as taxas de recidiva após a descontinuidade do uso. A *postectomia* é a retirada do anel estenótico prepucial que impede a esposição da glande.

##### Indicações cirúrgicas
- Redução do risco de infecções urinárias em pacientes com fimose e mal-formações congênitas do trato urinário
- Balanopostites de repetição
- Parafimose
- Desejo familiar em pacientes recém nascidos e menores que 3 anos


[^1]: JEDNAK, Roman; PIPPI SALLE, João Luiz. Circuncisão. _In_: KETZER, João Carlos. **Cirurgia Pediátrica - Teoria e Prática**. 1. ed. São Paulo: Roca, 2008. cap. 108, p. 561-566. ISBN 9788572416757.