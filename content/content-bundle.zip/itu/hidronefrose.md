---
title: "Hidronefrose"
link: "https://www.niddk.nih.gov/health-information/urologic-diseases/hydronephrosis-newborns"
---

A hidronefrose é a dilatação do sistema coletor renal. Pode ocorrer tanto como consequência de obstrução como por refluxo de urina. O mais comum é que a criança seja diagnosticada através de ultrassonografia ainda no período pré-natal. Em torno de 20% das crianças que nascem com hidronefrose apresentam resolução espontânea do quadro. Das que permanecem com hidronefrose persistente 44% possuem [[estenose da JUP]].

A hidronefrose pode ser classificada de acordo com o tamanho da pelve renal e com os efeitos compressivos que a pressão da pelve renal exerce sobre o parênquima renal.

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1652572803/garden/notas-cipe/hidronefrose_sfu_dmhsdf.png %}

>**Classificação da [Society for Fetal Urology (SFU)](http://www.sfu-urology.org/)**
>
> 0 - Rim normal
>
> I - leve dilatação da pelve, sem dilatação dos cálices, parênquima normal
>
>II – moderada dilatação da pelve, leve dilatação dos cálices, parênquima normal
>
>III – acentuada dilatação da pelve e dos cálices, parênquima normal
>
>IV – acentuada dilatação da pelve e dos cálices, redução da espessura do parênquima

De maneira geral, quanto maior for o DAPP (diâmetro anteroposterior da pelve) maior a chance de necessitar de cirurgia:

DAPP | Probabilidade de Cirurgia
<1cm|10%
1-2cm|45%
\>2cm|88%
