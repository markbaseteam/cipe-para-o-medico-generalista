---
title: "Infecção do trato urinário - ITU"
---


### Introdução

Infecção do trato urinário é uma das infecções mais comuns na infância. No primeiro ano de vida é mais comum em meninos (3.7%) quando comparado com as meninas (2%). Esta diferença se inverte após este período e próximo a puberdade é de 3% das meninas e 1% dos meninos. A recorrência de ITU no primeiro ano após um primeiro episódio pode chegar a 30% e a principal consequência é a formação de cicatrizes renais e a perda progressiva de função renal.

### Epidemiologia

Além do sexo outros fatores influenciam a incidência de ITU na infância, entre eles:

- Anomalias congênitas dos rins e vias urinárias
- Refluxo vesico-ureteral
- Presença do prepúcio nos meninos
- Sondagem vesical
- Raça caucasiana

Em torno de 90% dos casos das infecções são ocasionadas pela [_E. coli_ (UPEC ("Uropathogenic _E.coli_"))](https://pt.wikipedia.org/wiki/Escherichia_coli). Entre outros patógenos comuns podemos incluir: _Klebsiella_,
_Proteus_, _Enterococcus_, e _Enterobacter_
_spp_. _Pseudomonas, Streptococcus_ B,
e _Staphylococcus aureus_ geralmente acometem os pacientes portadores de anomalias congênitas, submetidos a cirurgia no trato genito-urinário ou usaram cateter vesical ou ainda infecções em pacientes que fizeram uso de antibiótico terapia recente. O _Proteus mirabilis_ devido a produção da urease e sua capacidade de quebrar a ureia em amônia e gás carbônico está implicado também na formação de cálculos renais.

### Cicatrizes renais
A maioria das ITU ocorrem devido a ascensão de bactérias pelo [urotélio](https://pt.m.wikipedia.org/wiki/Urot%C3%A9lio). As bactérias mais frequentemente implicadas são as encontradas em torno da uretra como os bacilos gram negativos da flora intestinal e alguns cocos gram positivos como o _Staphylococcus saprophyticus_. Disseminação hematogênica é mais observada em pacientes imunossuprimidos e apresentam maior frequência de infecções por fungos e _S. aureus_. A patogenicidade da _E. coli_ ocorre por ela possuir fímbrias e lipopolissacarídeos (LPS) em sua membrana, características que fornecem a está a capacidade de ascender pelo trato urinário e de se fixar ao urotélio. Os LPS são moléculas capazes de ativar os receptores [TLR4( _toll like receptor 4_)](https://pt.wikipedia.org/wiki/TLR4) uma proteína transmembrana presente nas células epiteliais e nos túbulos renais, capazes de ativar o sistema imunológico liberando citocinas pró-inflamatórias que atraem os neutrófilos. Os LPS por sua vez são estímulos diretos para o recrutamento de macrófagos, monócitos, linfócitos T e células dendríticas. A fibrose e as cicatrizes renais que se seguem decorrem da diferenciação dos monócitos em dois tipos: um pró-inflamatório que irá se diferenciar em macrófagos que irão perpetuar e amplificar a resposta inflamatória liberando fator de necrose tumoral α, espécies reativas de oxigênio e outros agentes citotóxicos e outro anti-inflamatório que poderá iniciar o processo de cicatriz renal liberando [TGF-β](https://en.wikipedia.org/wiki/Transforming_growth_factor_beta). No fim o processo que destrói os patógenos invasores é o mesmo que termina por destruir parte do parênquima renal e substituí-lo por fibrose.

### Diagnóstico

#### História clínica e exame físico

Em crianças mais velhas que se comunicam verbalmente é comum os achados de:
- disúria
- urgência
- dor abdominal ou em flanco direito
- perdas urinárias de início recente

Apesar destes, sinais e sintomas em crianças menores ou lactentes são bastante escassos e na maioria das vezes o único achado é o de febre, irritabilidade e recusa alimentar ou vômitos. Deve-se ainda colher antecedentes pessoais e familiares recentes de uso de antibióticos ou infecções bem como investigar a presença de constipação intestinal. No exame físico é possível perceber dor ou desconforto em região supra púbica ou em flanco e região lombar. Além de ser possível a palpação de massa em baixo ventre que pode representar fezes endurecidas e ressecadas ou retenção urinária, principalmente se presente após a micção espontânea.  

#### Exames complementares

A coleta de urina é um passo muito importante para a acurácia da análise de urina e cultura. Os métodos que apresentam menos contaminação nas crianças que ainda não usam o vaso sanitário é a cateterização e a punção supra púbica da bexiga com aspiração. A coleta com sacos coletores aderidos a pele da criança apresentam altos índices de contaminação principalmente nas meninas e meninos não circuncidados. Em geral as técnicas mais invasivas são utilizadas em crianças assintomáticas que apresentam um exame de urina colhido pelo método habitual ou quando existe dúvida no diagnóstico de infecção e se deseja confirmar com métodos que apresentam menos falsos positivos. Nas crianças que utilizam o vaso sanitário deve ser coletado o jato urinário médio após a degermação da pele do períneo nas meninas e do prepúcio nos meninos. Solicita-se ainda ao acompanhante ou ao paciente que retraia o prepúcio totalmente ou o máximo possível e nas meninas se afastar os grandes lábios ou urinar com o corpo voltado para o vaso sanitário o que naturalmente permite a coleta da urina sem que a mesma escorra pela pele da vulva ou do períneo.

**Sumário de urina**

Mesmo com todos os cuidados acima os métodos de triagem para infecção urinária em criança ainda apresentam altos índices de falsos negativos e positivos e isto implica no tratamento dos pacientes. Se tomarmos como exemplo uma coorte de 1000 crianças e uma prevalência de 7,5% de infecção urinária e utilizarmos somente o sumário de urina como indicador de tratamento clínico para esses pacientes, os resultados serão os da tabela abaixo:

|           #            | Sensibilidade (%) | Especificidade | não doentes mas tratados | doentes e não tratados |
| :--------------------: | :---------------: | :------------: | :----------------------: | :--------------------: |
|      Leucocitúria      |        79         |       87       |           120            |           16           |
|        Nitrito         |        49         |       98       |            18            |           38           |
| Leucocitúria + Nitrito |        88         |       79       |           184            |           9            |






