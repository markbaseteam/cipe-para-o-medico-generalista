---
title: "Rx de Tórax"
---

## _Checklist_

- Checar identificação do paciente e do exame.
- Checar a lateralidade está correta. 
- Bolha gástrica do lado esquerdo, fígado do lado direito e a marcação D/E ou L/R (_left_/_right_) condiz com o verificado na anatomia.
- Distância entre os processos espinhosos e a articulação esterno-clavicular (_devem estar iguais ou semelhantes, rx rodado_)
- Escápulas fora dos campos pulmonares
- Corpos vertebrais devem ser visíveis.

### Via aérea
- traqueia centralizada
- carina e brônquios fontes visíveis
- procurar corpos estranhos 

### Campos pulmonares
- verificar expansibilidade do pulmão (o aspecto reticular dos vasos pulmonares vai até a parte lateral tocando os arcos costais)
- procurar opacificações e assimetrias (processo infeccioso/colabamento de segmentos ou lobos)
- procurar por derrames ou pneumotórax 
	- seios costofrênicos 
	- seios cardiofrênicos
-   



