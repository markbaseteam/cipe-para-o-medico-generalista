---
title: "Pneumonia"
---

### Conceito

A pneumonia é uma infecção aguda das vias respiratórias que acomete os pulmões. Foi a causa da morte de 22% das crianças de 1 a 5 anos de idade. O que correspondeu a quase [750mil mortes em 2019][1]. Pneumonia pode ser causada por vírus, bactérias e fungos, e pode ser prevenida com boa nutrição, imunização e cuidados de saneamento básico.

### Etiopatologia

A identificação dos causadores das pneumonias é importante para a recomendação de uso de antibióticos empíricos, o desenvolvimento de vacinas e guiar o tratamento. Mas na maioria das vezes não é possível realizar a identificação do organismo causador da infecção, principalmente no caso de infecções bacterianas.

 **Razões que dificultam a identificação de agentes etiológicos nas pneumonias**
 - algumas bactérias patogênicas fazerem parte da flora bacteriana colonizante do ser humano
 - muitas não apresentam disseminação hematogênica o que dificulta o crescimento em hemoculturas
 - dificuldade em se coletar material das vias aéreas inferiores os quais muitas vezes apresentam crescimento de vários micro-organismos contaminantes

As infecções pelo pneumococo caíram desde a década de 90 principalmente após a introdução das vacinas anti-pneumocócicas e contra _Haemophilus influenzae_ tipo B (Hib). No entanto o primeiro ainda é responsável por cerca de 1/3 das pneumonias bacterianas seguido pelo Hib, _M. catarrhalis_, _S. aureus_ e estreptococo. Estes dois últimos evoluindo com mais frequência para [[empiema pleural]].

Apesar destes a maior parte das pneumonias são causadas por vírus, dentre eles o mais comum é o vírus sincicial respiratório (VSR). Que acomete principalmente crianças com menos de 2 anos. Outros também encontrados são o metapneumovírus, adenovírus, Influenza A/B, parainfluenza 1,2,3,, rinovírus, varicela vírus, citomegalovírus, enterovírus, herpes, bocavírus e mais recentemente o SARS-CoV-2. Até metade das infecções virais são infectadas concomitantemente por bactérias e a mais frequente delas é o pneumococo.

__Etiologia da PAC por idade do paciente__

- RN até 3 dias de vida
	- Estreptococo do grupo B, Bacilos Gram negativos e _Listeria monocytogenis_,  _Chlamydia trachomatis_
- 3 a 28 dias
	 - _Stafilococcus aureus_, _Stafilococcus epidermidis_, Gram negativos
- 1 a 3 meses
	 - Vírus,  _C. trachomatis_, _Ureaplasma urealyticum_, _Streptococcus pneumoniae_, _Stafilococcus aureus_
- 4 meses a 5 anos
	 - Vírus,  _Streptococcus pneumoniae_, _Stafilococcus aureus_, _Haemophilus influenzae_, _Moraxella catarrhalis_, _Mycoplasma pneumoniae_, _Chlamydia pneumoniae_, _Mycobacterium tuberculosis_
 - acima de 5 anos
	 - _Streptococcus pneumoniae_, _Stafilococcus aureus_, _Mycoplasma pneumoniae_, _Chlamydia pneumoniae_, _M. tuberculosis_


### Diagnóstico

Apesar de não haver sinais específicos de pneumonia, a maior parte dos diagnósticos se faz com os achados clínicos da anamnese e exame físico associados aos do raio x de tórax. Sinais de esforço respiratório, taquipneia e febre são os mais associados a quadros pneumônicos. A **tosse** e a **febre** (>37,5°C) estão presentes em mais de 80% das crianças com pneumonia. A **hipoxemia**  (StO₂<97%) também deve ser valorizado principalmente quando associado a esforço para respirar. A **taquipneia** tem valor maior para excluir pneumonia quando ausente que para confirmar pneumonia quando o sinal está presente.

 **Sinais e sintomas de pneumonia**

 - tosse
 - febre
 - desconforto respiratório (dispneia)
 - aumento da frequência respiratória (taquipneia)

A ausculta respiratória devido a sua alta variabilidade e baixa reprodutibilidade têm baixa sensibilidade e especificidade para o diagnóstico.  A **dor abdominal** pode estar presente em casos de pneumonia e as vezes ser a queixa principal. A **dor torácica** também é importante nos casos de empiema pleural e para o diagnóstico em adolescentes e crianças maiores. Os germes atípicos (_Mycoplasma pneumoniae_ e  _Chlamydia pneumoniae_) geralmente tem quadro que se inicia lentamente e geralmente associado a __tosse seca, indisposição, cefaleia, dor de garganta, otite média, febre ausente ou baixa__ além de poder ocorrer quadros extrapulmonares como:

- encefalite
- meningite asséptica
- neuropatia
- urticária
- púrpura

A presença de infiltrado hilar bilateral no RxT também deve levantar suspeita para infecções atípicas.

Muitas vezes os achados são semelhantes a quadros virais de infecção de vias aéreas superiores (IVAS) ou bronquiolite. A necessidade de internação é determinada pela presença de desconforto respiratório, hipoxemia e sinais sistêmicos de mal perfusão periférica. Há uma grande superposição de sintomas em crianças com pneumonia, bronquiolite e asma.

##### Quando internar o paciente com diagnóstico de pneumonia?

A resposta para essas pergunta não é objetiva, no entanto podemos utilizar de alguns critérios de gravidade que levam em conta a aparência, a circulação e a respiração ([[triangulo de avaliação pediátrica]])

Fatores a serem considerados na tomada de decisão quanto à hospitalização:

- Sinais clínicos de gravidade
  - SatO 2 < 92%; cianose о FR > 50 mpm (lactentes > 70) -
  - Taquicardia desproporcional à febre
  - Sinais de esforço respiratório
  - Tempo de enchimento capilar > 2s
  - Dificuldade para se alimentar
  - Gemência/apneia
  - Aparência toxêmica
  - Desidratação
- Fatores de risco de gravidade;
  - Cardiopatia congênita
  - Displasia broncopulmonar
  - Fibrose cística
  - Bronquiectasias
  - Imunodeficiência
- Presença de derrame pleural;
- Idade < 3-6 meses;
- Dificuldade alimentar / vômitos impedindo tratamento via oral
- Capacidade dos responsáveis de cuidar da criança

#### Raio X de tórax

Alguns _guidelines_ não recomendam a solicitação rotineira do [[raio x|raio x de tórax]] para avaliação de suspeita de **pneumonia de tratamento ambulatorial**.  Por não ter muita utilidade em diferenciar infecções bacterianas das virais; por não haver evidências de que influencie nos desfechos clínicos; por pneumonia bacteriana em suas fases iniciais poderem apresentar RxT normal; por apresentar baixa concordância  na interpretação quando se compara examinadores diferentes. No entanto, a definição clínica de pneumonia é bastante inespecífica e seus sinais e sintomas bastante subjetivos o que faz com que o RxT seja o exame mais solicitado para avaliação na suspeita de pneumonias.

<figure>
{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651696480/garden/notas-cipe/rx_pneumonia.jpg %}
<figcaption>infiltrado pneumônico em segmentos médios do pulmão esquerdo</figcaption>
</figure>

#### Ultrassonografia do tórax

Com a redução dos custos dos aparelhos de ultrassonografia e maior disponibilidade dos mesmos e devido a vantagem de não expor a criança a radiação a ultrassonografia têm sido cada vez mais utilizado como exame diagnóstico para pneumonias em crianças. Apesar disso ainda restam um longo caminho até o mesmo substituir o RxT. No momento é imprescindível o uso da ultrassonografia em casos de complicações locais da pneumonia bacteriana como derrames parapneumônicos e empiema pleural. Quando utilizado é também capaz de avaliar áreas de consolidação e atelectasias no parênquima pulmonar.

#### Laboratorial

##### Procalcitonina

Pode ser utilizada na conduta dos pacientes com pneumonia associada a outros achados clínicos. Valores de procalcitonina <0,25ng/mL podem com boa acurácia identificar crianças com risco baixo de pneumonia bacteriana as quais o uso de antibióticos não estaria indicado.

##### Hemograma e provas inflamatórias

O hemograma com leucograma, proteína C reativa (PCR), velocidade de hemossedimentação (VHS) são importantes para os pacientes em internação hospitalar no sentido de guiar a conduta clínica e avaliar a resposta do paciente ao tratamento com antibióticos. No entanto para o paciente com quadro pneumônico não grave de tratamento clínico ambulatorial alguns _guidelines_ dispensam a sua solicitação.

##### Hemoculturas

As hemoculturas não devem ser solicitadas para pacientes imunizados que serão tratados ambulatorialmente. Para os internados há algum benefício em solicitá-las apesar da taxa de positividade variar entre 2% e 7%.

### Tratamento

#### Ambulatorial

Indicado para pacientes sem desconforto respiratório que possam tomar o antibiótico por via oral.

> ##### Critérios para desconforto respiratório em crianças com pneumonia
>
>1. Taquipneia - frequência respiratória em incursões por min (ipm)
>
> - 0-2 meses de vida > 60ipm
> - 2-12 meses de vida > 50ipm
> - 1-5 anos de vida > 40ipm
> - \>5 aos de vida > 20ipm
>
> 2. Dispneia
> 3. Retração (subcostal, supra-esternal e intercostal)
> 4. Gemência
> 5. Batimento da aleta nasal
> 6. Apneia
> 7. Alteração do estado mental
> 8. Oximetria de pulso <90% em ar ambiente

Podemos ainda classificar os pacientes para tratamento ambulatorial em dois grupos de acordo com a idade:

- maiores de 5 anos
- menores de 5 anos

Esta classificação por idade é importante quando se leva em conta a prevalência maior de pneumonias atípicas nos maiores de 5 anos e a necessidade de cobertura antibiótica com macrolídeos para estes casos.

- Bacteriana
  - primeira linha => [[antibióticos|amoxicilina]]
  - alternativa => [[amoxicilina+clavulonato]]
- Atípica
  - primeira linha => [[azitromicina]]
  - alternativa => [[claritromicina]]

#### Hospitalar

##### escolha do antibiótico para paciente internado

A escolha do antibiótico para o paciente internado se baseia no _status_ vacinal do paciente para HiB e pneumococo e na etiologia, seja empiricamente ou orientada através de culturas, sorologias ou painéis virais quando disponíveis.



 ### Complicações relacionadas a pneumonia

 - **Pulmonares**
   - [[empiema pleural]]
   - pneumotórax
   - abscessos pulmonares
   - fístulas broncopleurais
   - pneumonia necrotizante
   - insuficiência respiratória aguda
 - **Metastática** (Embolias sépticas)
   - meningite
   - abscesso sistema nervoso central
   - pericardite
   - endocardite
   - osteomielite
   - artrite séptica
 - **Sistêmica**
   - sepse ou síndrome da resposta inflamatória sistêmica
   - síndrome hemolítico-urêmica (SHU)

[1]: https://www.who.int/news-room/fact-sheets/detail/pneumonia
