---
layout: page
title: "Meu filho está tossindo"
permalink: /meu-filho-está-tossindo
---
## Meu filho está tossindo

Por onde começar:

- [[efusão pleural]]
- [[empiema pleural]]
- [[pneumonia]]

Objetivos:

- O que são pneumonias e empiemas e como eles acontecem?
- Como avaliar um Rx de tórax no PA de forma sistematizada.
- Quando solicitar USG de tórax e TAC e o que fazer com os resultados.
- Quais os principais antibióticos e procedimentos que podem ser realizados no paciente com empiema pleural/Pneumonia.
