---
title: "Efusões pleurais"
---

### Conceito

É o acúmulo anormal de líquido no espaço pleural. O espaço virtual que inclui a parte da cavidade torácica que contém os pulmões. Este espaço é delimitado por uma membrana serosa chamada pleura que recobre a parede torácica internamente e os pulmões, recebendo os nomes de pleural visceral e pleural parietal. A pleural parietal, principalmente, produz uma pequena quantidade de líquido pleural na velocidade de 0.2mL/kg/h que é continuamente reabsorvido pelos vasos linfáticos torácicos. Normalmente existe uma quantidade mínima deste líquido na cavidade pleural. E este tem a função de auxiliar na mecânica respiratória contribuindo com a pressão negativa que acontece neste espaço quando há expansão do tórax na inspiração e diminuindo a fricção das pleuras visceral e parietal uma sobre a outra. A principal causa de efusão pleural na criança são os exsudatos parapneumônicos encontrados no [[empiema pleural]].

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1651698694/garden/notas-cipe/causas_efusao_pleural.png %}


### Fisiopatologia

A quantidade de liquido pleural é determinada pela diferença de pressão oncótica e hidrostática da circulação sistêmica e pulmonar. O sistema linfático é capaz de absorver até 20 vezes mais liquido do que em uma situação fisiológica, podendo assim responder a largas variações na produção de liquido pleural mantendo o equilíbrio entre produção e absorção. O acúmulo de líquido pleural e as efusões pleurais ocorrem quando há quebra desse equilíbrio. Pressão oncótica baixa, pressão capilar pulmonar elevada, aumento da permeabilidade capilar e diminuição da pressão negativa intrapleural são fatores fisiopatológicos que determinam a efusão pleural e suas formas clínicas de _exsudato e transudato_.

> ### Causas comuns de efusões pleurais
> - **Transudato**
> 	- Insuficiência cardíaca congestiva
> 		- edema, cianose
> 		- histórico de doença cardíaca, sopros
> 	- Trombo-embolismo pulmonar (TEP)* 
> 		- dispneia, imobilização
> 		- dor pleurítica
> 	- Síndrome nefrótica
> 		- hipoalbuminemia
> 	- Cirrose hepática
> 		- icterícia, ascite 
> 		- edema de membros inferiores
> - **Exsudato**
> 	- Câncer
> 		- história de malignidade
> 		- massa torácica
> 	- Pneumonia Bacteriana
> 		- tosse, febre
> 		- opacificação ao rx de tórax

<small>*exsudato também é possível</small>

### Apresentação clínica
A maioria dos sintomas e sinais estarão relacionados com a doença subjacente que ocasionou a efusão pleural, raramente algum sinal ou sintoma estará relacionado exclusivamente com a efusão. No entanto, quando a efusão restringe mecanicamente a expansão pulmonar, perturba as trocas gasosas ou apresenta sinais relacionados aos processos inflamatórios na pleura, estes podem ser atribuídos a presença do exsudato ou transudato pleural. 

##### **Dor pleurítica** 

A dor é o principal sintoma que ocorre secundariamente a inflamação na cavidade pleural, se origina eminentemente dos [nociceptores][1] presentes na pleura parietal uma vez que não existem fibras nervosas ou receptores para dor na pleura visceral. Muitas vezes a dor está relacionada com o ciclo respiratório de inspiração e expiração e se inicia tão logo o processo inflamatório se estenda até a pleura parietal. Os pacientes referem uma dor em peso no peito localizada na região externa onde se localiza a efusão pleural que acomete a mesma. Na maior parte dos casos as efusões pleurais que causam dor são do tipo exsudativo e podem estar presentes no [[empiema pleural]], carcinomatose pleural e tumores primários da pleura (mais comuns em adultos).

##### **Dispneia**

É o sintoma mais comum nas efusões pleurais. Se deve a presença da efusão ocupando espaço que antes era ocupado por parênquima pulmonar. Apesar do efeito causal o volume do derrame não implica o colabamento imediato do parênquima pulmonar, nem a sua drenagem com a expansão do mesmo. Esta sensação de melhora da dispneia após a drenagem geralmente se dá por uma maior facilidade na contração da musculatura respiratória.

> - As **manifestações clínicas** das efusões pleurais são dependentes da causa subjacente.
> - A **dispneia** é o sintoma mais frequente nos pacientes com efusões pleurais.
















[1]: https://pt.wikipedia.org/wiki/Nociceptor#:~:text=Nociceptor%20%C3%A9%20um%20receptor%20sensorial,poss%C3%ADveis%20manifesta%C3%A7%C3%B5es%20de%20dor%20persistente.