---
title: "Empiema Pleural"
---

O empiema pleural é o acúmulo de líquido infectado na cavidade pleural. É considerado um tipo de [[efusão pleural]] e também chamado de piotórax. Na maior parte das crianças esse processo ocorre de forma secundária a uma pneumonia grave com um exsudato para pneumônico.

### Fisiopatologia

A formação do empiema pode ser dividido em três fases distintas que se sucedem ao longo do tempo:

- __Aguda ou exsudativa.__
	- Ocorre nas primeiras 24h-72h e se caracteriza por líquido fluido e transparente que percorre livremente toda a cavidade pleural que se encontra livre de traves ou septos que delimitem espaços menores. Também é chamada de efusão parapneumônica e pode ser tratado com toracocentese ou drenagem fechada.
- __Transição ou fibrinopurulenta__
	- Esta fase dura em torno de 7 a 10 dias e é marcada pela presença de fluido espesso e formado por polimorfonucleares/neutrófilos. A formação de lojas e divisões do espaço pleural dificulta o tratamento somente com drenagem de tórax.
- __Crônica ou encarceramento__
	- Se desenvolve em torno de 2 a 4 semanas após o início do quadro e se caracteriza pelo espessamento da pleura visceral e parietal devido a presença crescente e atividade aumentada dos fibroblastos. Essa camada espessada é responsável pelo sequestro e encarceramento do parênquima pulmonar subjacente e suas consequências. 

### Etiopatogenia

A etiologia bacteriana do empiema pleural mudou muito nos últimos 50 anos, o _Streptococcus pneumoniae_ que antes era o principal e mais frequente agente causador foi substituído pelo  _Staphylococcus aureus_ provavelmente devido a introdução dos beta-lactâmicos e da vacinação antipneumocócica. Hoje a maioria dos pacientes pediátricos com empiema apresentam cultura positiva para _S. aureus_ bem como 50% dos pacientes adultos. Outros organismos incluem o _Haemophilus influenza_, _Pseudomonas aeruginosa_ e várias espécies de _Bacteroides_. 

### Diagnóstico

O quadro clínico em geral é o de um paciente que apresenta um quadro de infecção pulmonar ao qual se segue desconforto respiratório de intensidade variável, febre e tosse. Dor torácica, nos ombros ou abdominal associada a íleo paralítico pode intensificar a dificuldade respiratória. A opacificação uni ou bilateral dos campos pulmonares ao raio x pode representar tanto consolidação pulmonar pelo processo pneumônico como atelectasias ou fluído infectado no espaço pleural. No início do quadro de empiema o líquido infectado flui livremente por toda a cavidade pleural podendo ser possível demonstrar através da mudança de decúbito do paciente ao se realizar o exame de raios x. Na fase fibrinopurulenta o liquido já é espesso o suficiente para não haver mobilização durante os diferentes decúbitos o que também dificulta o tratamento com drenagem torácica. Neste período a presença de níveis líquido-ar na cavidade pleural podem representar infecção por anaeróbios. A toracocentese é um procedimento capaz de fornecer informações valiosas para o diagnóstico apesar de que muitas sua necessidade é dispensada principalmente nas crianças. Os seguintes achados são critérios para o diagnóstico de empiema pleural: 
> - Presença de pus no aspirado da cavidade pleural
> - Bactérias presentes na bacterioscopia ou no Gram
> - pH < 7.0; DHL > 1000 U/mL; Glicose < 40mg/dL [(Critérios de Light)](https://en.wikipedia.org/wiki/Pleural_effusion#Light's_criteria)

{% cloudinary https://res.cloudinary.com/danielrangel/image/upload/v1653166672/garden/notas-cipe/Empiema_-_Frame_2_qt3pjh.jpg %} 

### Tratamento
O tratamento consiste na antibioticoterapia como indicada para as [[pneumonia]]. O empiema pleural que muda de localização com a mudança de decúbito é um ótimo candidato para ser drenado através de um dreno torácico em selo d'agua fechado. Nos pacientes com empiema na fase fibrinopurulenta em diante o dreno torácico de forma isolada não é tão eficaz e o melhor tratamento ainda é motivo de debate com alguns cirurgiões optando pela drenagem simples, por uso de fibrinolíticos para lise das lojas e septações e outros pela [VATS (_video-assisted thoracic surgery_)](https://www.lung.org/lung-health-diseases/lung-procedures-and-tests/video-assisted-thoracic-surgery). O tratamento específico ainda não é definido. O uso de fibrinolíticos se mostrou economicamente mais viável e comparável a VATS principalmente nos pacientes com mais de 10 dias de história clínica. É consenso que nos pacientes que apresentam loculações e septações seja optado pelo tratamento com fibrinolíticos ou VATS pois dificilmente a drenagem torácica isolada irá resolver o quadro.
