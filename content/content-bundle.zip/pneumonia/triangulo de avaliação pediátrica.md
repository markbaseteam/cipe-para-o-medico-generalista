---
title: "Triângulo de avaliação pediátrica"
---

**Triangulo de avaliação pediátrica**

- Aparência (_TICLS_)
  - Tônus
  - Interação/estado mental
  - Consolação
  - Olhar (_look_)
  - Fala (_cry)_)
- Respiração
  - posição do corpo
  - sons anormais
  - retração costal
  - batimento aletas nasais
- Circulação
  - palidez
  - manchas
  - cianose

A partir destes dados é possível classificar o paciente como _doente_, instável e que provavelmente necessitará de abordagens para problemas específicos apresentados durante a avaliação e _não doente_, estável que poderá ser avaliado sistemicamente com uma história direcionada e mais detalhada sendo um candidato para tratamento ambulatorial